"""Generate only the requested combined six-DOF and controller figures."""
from runpy import run_path
from pathlib import Path

run_path(str(Path(__file__).resolve().with_name("plot_final_project.py")), run_name="__main__")
