"""Selectable guidance/controllers for the underactuated 8-state AUV model.

Modes:
  nmpc      - existing lightweight finite-horizon predictive action search
  pid       - cascaded position/speed/heading/depth PID controller
  los-pid   - line-of-sight path-following with PID speed/depth/yaw loops
  robust-pd - damped inverse-dynamics PD with a bounded robust term

These are simulation controllers, not safety-certified autopilots. Every mode
returns the project's three generalized inputs [longitudinal force, vertical
force, yaw moment], which are subsequently passed through the common safety
shield and rate/magnitude limits in main.py.
"""
from __future__ import annotations
import math
import numpy as np

from .controller import RobustNMPC
from .dynamics import AUVParams, wrap_angle

CONTROLLER_LABELS = {
    "nmpc": "Finite-horizon predictive (NMPC-style)",
    "pid": "Cascaded PID",
    "los-pid": "Line-of-sight + PID",
    "robust-pd": "Damped inverse-dynamics PD",
}


class ControllerBank:
    MODES = tuple(CONTROLLER_LABELS.keys())

    def __init__(self, params: AUVParams, dt=0.10, horizon=9, control_every=2,
                 cruise_speed=0.70, tau_max=(140.0, 100.0, 60.0)):
        self.p = params
        self.dt = float(dt)
        self.control_dt = self.dt * max(1, int(control_every))
        self.cruise_speed = float(cruise_speed)
        self.tau_max = np.asarray(tau_max, dtype=float)
        self.nmpc = RobustNMPC(params, dt=dt, horizon=horizon, control_interval=control_every)
        self.mode = "nmpc"
        self.integrals = np.zeros(3, dtype=float)
        self.prev_errors = np.zeros(3, dtype=float)
        self.previous_tau = np.zeros(3, dtype=float)
        self.last_mode_note = ""

    def set_mode(self, mode: str):
        key = str(mode).lower().replace("_", "-")
        if key not in self.MODES:
            raise ValueError(f"Unknown controller '{mode}'. Choose from: {', '.join(self.MODES)}")
        if key != self.mode:
            self.mode = key
            self.integrals[:] = 0.0
            self.prev_errors[:] = 0.0
            self.previous_tau[:] = 0.0
            self.nmpc.prev[:] = 0.0
            self.last_mode_note = f"Controller switched to {CONTROLLER_LABELS[key]}"

    def next_mode(self):
        i = self.MODES.index(self.mode)
        self.set_mode(self.MODES[(i + 1) % len(self.MODES)])
        return self.mode

    def _inverse_surge(self, x, desired_u, accel_cmd):
        p = self.p
        u, v, r = float(x[4]), float(x[5]), float(x[7])
        return p.m11 * accel_cmd - p.m22 * v * r - p.Xu * u - p.Xu_abs * u * abs(u)

    def _inverse_heave(self, x, desired_w, accel_cmd):
        p = self.p
        w = float(x[6])
        return p.m33 * accel_cmd - (p.W - p.B) - p.Zw * w - p.Zw_abs * w * abs(w)

    def _update_integral(self, idx, err, limit):
        self.integrals[idx] = float(np.clip(self.integrals[idx] + err * self.control_dt, -limit, limit))
        return self.integrals[idx]

    def _target_errors(self, x, refs):
        target = np.asarray(refs[:3, 0], dtype=float)
        d = target - np.asarray(x[:3], dtype=float)
        distance_xy = float(np.hypot(d[0], d[1]))
        bearing = math.atan2(d[1], d[0]) if distance_xy > 1e-6 else float(refs[3, 0])
        return target, d, distance_xy, bearing

    def _pid(self, x, refs, los=False):
        target, d, dist_xy, bearing = self._target_errors(x, refs)
        # LOS uses the path tangent as its desired course; waypoint PID aims at
        # the local preview point. Both slow down as the preview target is reached.
        desired_yaw = float(refs[3, 0]) if los else bearing
        yaw_err = wrap_angle(desired_yaw - float(x[3]))
        forward_alignment = max(0.0, math.cos(yaw_err))
        u_des = float(np.clip(0.55 * dist_xy, 0.0, self.cruise_speed) * forward_alignment)
        # Depth is tracked with a bounded vertical-speed target.
        w_des = float(np.clip(0.48 * d[2], -0.38, 0.38))

        eu = u_des - float(x[4])
        ew = w_des - float(x[6])
        ir = self._update_integral(0, eu, 1.8)
        iw = self._update_integral(1, ew, 1.5)
        iy = self._update_integral(2, yaw_err, 1.5)

        if los:
            au = 2.2 * eu + 0.12 * ir
            aw = 2.5 * ew + 0.12 * iw
            yaw_cmd = 30.0 * yaw_err - 15.0 * float(x[7]) + 0.8 * iy
        else:
            au = 2.8 * eu + 0.18 * ir
            aw = 2.9 * ew + 0.16 * iw
            yaw_cmd = 36.0 * yaw_err - 17.0 * float(x[7]) + 1.0 * iy

        tau = np.array([
            self._inverse_surge(x, u_des, au),
            self._inverse_heave(x, w_des, aw),
            yaw_cmd - (self.p.m11 - self.p.m22) * float(x[4]) * float(x[5]),
        ], dtype=float)
        return np.clip(tau, -self.tau_max, self.tau_max)

    def _robust_pd(self, x, refs):
        _, d, dist_xy, bearing = self._target_errors(x, refs)
        yaw_err = wrap_angle(bearing - float(x[3]))
        u_des = float(np.clip(0.42 * dist_xy, 0.0, self.cruise_speed) * max(0.0, math.cos(yaw_err)))
        w_des = float(np.clip(0.40 * d[2], -0.34, 0.34))
        eu, ew = u_des - float(x[4]), w_des - float(x[6])
        # Smooth bounded robust terms reduce sensitivity to modest residual errors;
        # they are heuristic terms, not a formal robust-stability guarantee.
        au = 2.5 * eu - 0.55 * math.tanh(eu / 0.08)
        aw = 2.6 * ew - 0.45 * math.tanh(ew / 0.08)
        yaw_cmd = 33.0 * yaw_err - 19.0 * float(x[7]) - 2.5 * math.tanh(yaw_err / 0.12)
        tau = np.array([
            self._inverse_surge(x, u_des, au),
            self._inverse_heave(x, w_des, aw),
            yaw_cmd - (self.p.m11 - self.p.m22) * float(x[4]) * float(x[5]),
        ], dtype=float)
        return np.clip(tau, -self.tau_max, self.tau_max)

    def solve(self, x, refs, obstacle_blocks):
        x = np.asarray(x, dtype=float)
        refs = np.asarray(refs, dtype=float)
        if self.mode == "nmpc":
            tau, feasible = self.nmpc.solve(x, refs, obstacle_blocks)
        elif self.mode == "pid":
            tau, feasible = self._pid(x, refs, los=False), True
        elif self.mode == "los-pid":
            tau, feasible = self._pid(x, refs, los=True), True
        else:
            tau, feasible = self._robust_pd(x, refs), True
        self.previous_tau = np.asarray(tau, dtype=float).copy()
        return self.previous_tau.copy(), feasible
