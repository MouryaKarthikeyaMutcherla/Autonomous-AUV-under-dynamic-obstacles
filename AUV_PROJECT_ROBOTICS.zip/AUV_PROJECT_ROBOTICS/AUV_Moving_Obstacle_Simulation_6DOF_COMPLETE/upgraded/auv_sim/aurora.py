from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d

ALIASES = {
    'x': ['x','x_m','position_x','pos_x','east','easting','utm_e','nav_x'],
    'y': ['y','y_m','position_y','pos_y','north','northing','utm_n','nav_y'],
    'depth': ['depth','depth_m','z','z_m','position_z','pos_z','altitude','nav_z'],
    'heading': ['heading','yaw','psi','heading_deg','yaw_deg'],
    'time': ['time','timestamp','time_s','elapsed','seconds','sec'],
    'lat': ['latitude','lat'],
    'lon': ['longitude','lon','long'],
}

def _find_col(df, options):
    low = {str(c).strip().lower(): c for c in df.columns}
    for name in options:
        if name in low:
            return low[name]
    for c in df.columns:
        lc = str(c).strip().lower()
        if any(name in lc for name in options):
            return c
    return None


def load_aurora_track(root='data/aurora'):
    root = Path(root)
    files = sorted(root.rglob('*.csv')) if root.exists() else []
    candidates = []
    for f in files:
        try:
            df = pd.read_csv(f)
        except Exception:
            continue
        cx, cy = _find_col(df, ALIASES['x']), _find_col(df, ALIASES['y'])
        cdep = _find_col(df, ALIASES['depth'])
        clat, clon = _find_col(df, ALIASES['lat']), _find_col(df, ALIASES['lon'])
        if (cx and cy) or (clat and clon):
            candidates.append((len(df), f, df, cx, cy, cdep, clat, clon))
    if not candidates:
        return None, 'No AURORA navigation CSV found; using built-in demo track.'
    _, f, df, cx, cy, cdep, clat, clon = max(candidates, key=lambda z: z[0])

    if cx and cy:
        x = pd.to_numeric(df[cx], errors='coerce').to_numpy(dtype=float)
        y = pd.to_numeric(df[cy], errors='coerce').to_numpy(dtype=float)
    else:
        lat = pd.to_numeric(df[clat], errors='coerce').to_numpy(dtype=float)
        lon = pd.to_numeric(df[clon], errors='coerce').to_numpy(dtype=float)
        lat0, lon0 = np.nanmedian(lat), np.nanmedian(lon)
        x = (lon-lon0)*111320.0*np.cos(np.deg2rad(lat0))
        y = (lat-lat0)*110540.0

    if cdep:
        zraw = pd.to_numeric(df[cdep], errors='coerce').to_numpy(dtype=float)
        # Convert depth-positive-down to Z-positive-up.
        depth = zraw - np.nanmedian(zraw)
        z = -depth
    else:
        z = np.full_like(x, -10.0)

    ch = _find_col(df, ALIASES['heading'])
    if ch:
        h = pd.to_numeric(df[ch], errors='coerce').to_numpy(dtype=float)
        if np.nanmax(np.abs(h)) > 2*np.pi+0.5:
            h = np.deg2rad(h)
    else:
        dx = np.gradient(x)
        dy = np.gradient(y)
        h = np.arctan2(dy, dx)

    tcol = _find_col(df, ALIASES['time'])
    if tcol:
        t = pd.to_numeric(df[tcol], errors='coerce').to_numpy(dtype=float)
        t = t - np.nanmin(t)
    else:
        t = np.arange(len(x), dtype=float)

    ok = np.isfinite(x) & np.isfinite(y) & np.isfinite(z) & np.isfinite(h)
    x, y, z, h, t = x[ok], y[ok], z[ok], h[ok], t[ok]
    if len(x) < 20:
        return None, f'AURORA candidate {f} is too small; using built-in demo track.'

    # Normalize to a compact local mission envelope and smooth noisy sensor trajectory.
    sx = gaussian_filter1d(x, 4)
    sy = gaussian_filter1d(y, 4)
    sz = gaussian_filter1d(z, 4)
    scale = max(np.ptp(sx), np.ptp(sy), 1.0)
    target_span = 42.0
    sx = (sx - np.mean(sx)) * target_span / scale
    sy = (sy - np.mean(sy)) * target_span / scale
    sz = np.clip(-9.0 + 0.25*(sz-np.mean(sz)), -18.0, -5.0)
    h = np.unwrap(h)
    return {'x':sx,'y':sy,'z':sz,'heading':h,'time':t}, f'Using AURORA navigation track: {f}'


def demo_track(n=800):
    t = np.linspace(0, 1, n)
    x = -24 + 50*t
    y = -11 + 12*np.sin(1.3*np.pi*t) + 2.0*np.sin(4*np.pi*t)
    z = -7 - 10*t + 0.8*np.sin(3*np.pi*t)
    h = np.unwrap(np.arctan2(np.gradient(y), np.gradient(x)))
    return {'x':x,'y':y,'z':z,'heading':h,'time':t}


def resample_track(track, n=1400):
    from scipy.interpolate import CubicSpline
    s = np.linspace(0, 1, len(track['x']))
    ss = np.linspace(0, 1, n)
    out = {}
    for k in ['x','y','z']:
        out[k] = CubicSpline(s, track[k])(ss)
    out['heading'] = np.unwrap(np.arctan2(np.gradient(out['y']), np.gradient(out['x'])))
    out['time'] = ss
    return out
