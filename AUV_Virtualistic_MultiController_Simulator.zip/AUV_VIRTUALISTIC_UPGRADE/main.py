from __future__ import annotations

import argparse
import csv
import math
import time
import copy
import shutil
from pathlib import Path

import numpy as np
import vtk

from config import CFG
from auv_sim.aurora import demo_track, load_aurora_track, resample_track
from auv_sim.controller import tube_feedback
from auv_sim.controller_modes import ControllerBank, CONTROLLER_LABELS
from auv_sim.dynamics import AUVParams, dynamics, plant_params, rk4, sample_current, sample_disturbance, wrap_angle
from auv_sim.planner import (
    MovingSphere,
    Sphere,
    build_3d_time_astar,
    simplify_timed_path,
)
from auv_sim.scene import (
    actor,
    coral_cluster,
    cube,
    dynamite_cache,
    line_actor,
    make_auv_actor,
    make_debris_actor,
    make_submersible_actor,
    point_cloud,
    seabed,
    water_surface,
    light_beams,
    sea_grass,
    rock_field,
    pipeline,
    cable_bundle,
    fish_actor,
    text_actor,
    sphere,
    container,
    wreck_ship,
)


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)

BOUNDS = ((-30.0, 30.0), (-18.0, 18.0), (-22.0, -2.0))


# -----------------------------------------------------------------------------
# Underwater world
# -----------------------------------------------------------------------------
# Collision geometry is deliberately simpler than the visual geometry. The
# controller plans against inflated spheres while the VTK scene shows natural
# looking coral, wreck, containers, rocks and a hazardous cache.
STATIC = []

reef_centers = [
    (-17.0, -5.0, -18.7),
    (-11.0, 6.0, -18.5),
    (3.5, 8.5, -18.8),
    (12.0, -8.0, -18.8),
    (21.0, 5.0, -18.7),
]
for i, c in enumerate(reef_centers):
    STATIC.append(Sphere(f"Coral Reef {i + 1}", np.array(c, float), 2.8, "reef"))

STATIC += [
    Sphere("Wrecked Ship", np.array([-2.0, -2.5, -18.0]), 4.6, "wreck"),
    Sphere("Wrecked Ship Bow", np.array([4.0, -2.3, -17.6]), 2.5, "wreck"),
    Sphere("Old Container A", np.array([8.5, -1.5, -18.1]), 2.7, "container"),
    Sphere("Old Container B", np.array([-5.0, 9.0, -18.0]), 2.4, "container"),
    Sphere("Hazard Cache", np.array([16.5, -0.5, -18.4]), 2.0, "hazard"),
]

for i, c in enumerate([
    (-24, 11, -19.0),
    (-20, -10, -19.0),
    (1.0, -10.5, -19.0),
    (15, 11, -18.9),
    (25, -10, -19.0),
]):
    STATIC.append(Sphere(f"Rock {i + 1}", np.array(c, float), 1.7, "rock"))


# Moving obstacles. Their motion is known to the simulation plant but only
# predicted when they enter the AUV's sensing region.
MOVING = [
    MovingSphere(
        "Moving Survey Drone",
        np.array([-13.0, -5.0, -10.5]),
        np.array([0.32, 0.20, 0.0]),
        1.15,
        0.0,
        wobble=0.55,
        active_duration=48.0,
    ),
    MovingSphere(
        "Moving Debris",
        np.array([11.0, -13.0, -12.2]),
        np.array([-0.18, 0.30, 0.0]),
        0.95,
        1.8,
        wobble=0.40,
        active_duration=58.0,
    ),
    MovingSphere(
        "Passing Submersible",
        np.array([25.0, 15.0, -14.0]),
        np.array([-0.28, -0.22, 0.0]),
        1.25,
        5.5,
        wobble=0.45,
        active_duration=68.0,
    ),
]


SCENARIOS = {
    "calm":   {"current": 0.35, "disturbance": 0.35, "obstacle_speed": 0.70},
    "nominal": {"current": 1.00, "disturbance": 1.00, "obstacle_speed": 1.00},
    "rough":  {"current": 1.80, "disturbance": 1.75, "obstacle_speed": 1.35},
}


class Simulation:
    def __init__(self, headless=False, controller_mode="nmpc", scenario="nominal",
                 current_scale=None, disturbance_scale=None, seed=None,
                 position_noise_m=0.0, heading_noise_deg=0.0,
                 dynamic_avoidance=True, reference_mode="auto"):
        self.headless = bool(headless)
        self.t = 0.0
        self.frame = 0
        self.paused = False
        self.camera_mode = "overview"
        self.scenario = scenario if scenario in SCENARIOS else "nominal"
        self.reference_mode = reference_mode if reference_mode in ("auto", "aurora", "demo") else "auto"
        preset = SCENARIOS[self.scenario]
        self.current_scale = float(preset["current"] if current_scale is None else current_scale)
        self.disturbance_scale = float(preset["disturbance"] if disturbance_scale is None else disturbance_scale)
        self.obstacle_speed_scale = float(preset["obstacle_speed"])
        self.dynamic_avoidance_enabled = bool(dynamic_avoidance)
        self.position_noise_m = max(0.0, float(position_noise_m))
        self.heading_noise_rad = math.radians(max(0.0, float(heading_noise_deg)))
        self.seed = int(CFG.seed if seed is None else seed)
        self.sensor_rng = np.random.default_rng(self.seed + 701)
        self.moving_obstacles = copy.deepcopy(MOVING)
        for obs in self.moving_obstacles:
            obs.velocity = np.asarray(obs.velocity, dtype=float) * self.obstacle_speed_scale

        self.nom = AUVParams()
        self.plant = plant_params()

        self.x = np.array([*CFG.launch_point, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=float)
        self.nominal = self.x.copy()
        self.current = np.zeros(3)
        self.dist = np.zeros(3)
        self.last_applied_tau = np.zeros(3)
        self.commanded_tau = np.zeros(3)
        self.nominal_tau = np.zeros(3)

        self.controller_bank = ControllerBank(
            self.nom, dt=CFG.dt, horizon=CFG.horizon,
            control_every=CFG.control_every, cruise_speed=CFG.cruise_speed,
            tau_max=CFG.tau_max,
        )
        self.controller_bank.set_mode(controller_mode)
        # Keep a reference to the predictive controller for its horizon timing.
        self.controller = self.controller_bank.nmpc
        self.controller_mode = self.controller_bank.mode

        self.goal = np.array(CFG.mission_goal, dtype=float)
        self.route = None
        self.route_times = None
        self.route_history = []
        self.replans = 0
        self.last_plan = -1e9
        self.status = "DEPLOYING"
        self.mission_complete = False

        self.min_clearance = 1e9
        self.max_track_error = 0.0
        self.collisions = 0
        self.rows = []
        self.detected_names = []
        self.last_measurement = self.x.copy()
        self._path_geometry_cache = {}
        self.last_route_notice = "No route yet"

        # Navigation loader explicitly prefers navigation/GPS exports and excludes
        # multibeam/echaosounder index files. The selected navigation trace is mapped
        # into the scene envelope for route context; it is not ground-truth AUV dynamics.
        if self.reference_mode == "demo":
            tr, msg = demo_track(), "Using built-in demonstration track (selected by --reference demo)."
            self.aurora_used = False
        else:
            tr, msg = load_aurora_track(ROOT / "data" / "aurora")
            if tr is None:
                tr = demo_track()
                self.aurora_used = False
                if self.reference_mode == "aurora":
                    msg = "AURORA navigation reference requested but no valid navigation export was found; using demo track."
            else:
                self.aurora_used = True
        self.aurora_msg = msg
        self.aurora_track = resample_track(tr, 600)
        self.aurora_trace = self._make_aurora_ghost()
        if self.aurora_used:
            self.aurora_trace = self._select_mission_segment(self.aurora_trace)
            self.aurora_msg += " | using a smoothed ~22-30 m AURORA-derived segment mapped to the local simulation scene"

        if self.aurora_used:
            self.goal = self.aurora_trace[-1].copy()
            st = self.aurora_trace[0]
            self.x = np.array([st[0], st[1], CFG.launch_point[2], 0.0, 0.0, 0.0, 0.0, 0.0], dtype=float)
            self.nominal = self.x.copy()

        if not self.headless:
            self._make_scene()

    # ------------------------------------------------------------------
    # AURORA context
    # ------------------------------------------------------------------
    @staticmethod
    def _select_mission_segment(points, target_length=25.0):
        """Select a continuous, reasonably direct route segment for one mission.

        The source navigation export may describe a long survey with turns and
        repeated passes. The full trace is too long for the default mission time
        after it is mapped into this compact scene. Select a 32-42 m arclength
        window with a useful start-to-goal displacement; the selected segment is
        still smoothed AURORA reference context, not vehicle-dynamics ground truth.
        """
        points = np.asarray(points, dtype=float)
        if len(points) < 8:
            return points.copy()
        lens = np.linalg.norm(np.diff(points, axis=0), axis=1)
        cumulative = np.concatenate(([0.0], np.cumsum(lens)))
        candidates = []
        for i in range(0, len(points)-5, 2):
            j = int(np.searchsorted(cumulative, cumulative[i] + target_length, side="left"))
            if j >= len(points):
                continue
            path_len = float(cumulative[j] - cumulative[i])
            chord = float(np.linalg.norm(points[j] - points[i]))
            if 22.0 <= path_len <= 30.0 and chord >= 19.5:
                directness = chord / max(path_len, 1e-6)
                # Slightly prefer a sizeable goal displacement while favouring
                # less tortuous windows so a student-laptop mission is feasible.
                score = directness + 0.0015 * chord - 0.001 * abs(path_len-target_length)
                candidates.append((score, i, j))
        if not candidates:
            return points.copy()
        _, i, j = max(candidates, key=lambda item: item[0])
        ids = np.unique(np.r_[np.arange(i, j + 1, 2), j]).astype(int)
        return points[ids]

    def _make_aurora_ghost(self):
        p = np.c_[self.aurora_track["x"], self.aurora_track["y"], self.aurora_track["z"]]
        x, y, z = p[:, 0], p[:, 1], p[:, 2]

        # Map dataset coordinates so the track spans across the full interactive 3D environment [-24, +24]
        x_ptp = np.ptp(x) if np.ptp(x) > 1e-3 else 1.0
        x_norm = -24.0 + (x - np.min(x)) / x_ptp * 48.0

        y_ptp = np.ptp(y) if np.ptp(y) > 1e-3 else 1.0
        y_norm = (y - np.mean(y)) / y_ptp * 22.0

        z_ptp = np.ptp(z) if np.ptp(z) > 1e-3 else 1.0
        z_norm = np.clip(-11.0 + (z - np.mean(z)) / z_ptp * 7.0, -17.5, -5.0)

        return np.c_[x_norm, y_norm, z_norm]


    # ------------------------------------------------------------------
    # Planning and prediction
    # ------------------------------------------------------------------
    def current_obstacles(self):
        # The controller only gets obstacles that are inside the simulated sensor
        # range. Unknown obstacles are effectively absent from its local map.
        blocks = np.zeros((4 * len(self.moving_obstacles), CFG.horizon + 1), dtype=float)
        blocks[:, :] = 0.0
        for i in range(len(self.moving_obstacles)):
            blocks[4 * i + 3, :] = 1e6

        detected = []
        horizon_seconds = CFG.horizon * self.controller.control_dt
        active = []
        if not self.dynamic_avoidance_enabled:
            return blocks, detected, horizon_seconds
        for d in self.moving_obstacles:
            now_dist = np.linalg.norm(d.position(self.t) - self.x[:3])
            soon_dist = min(np.linalg.norm(d.position(tt) - self.x[:3]) for tt in np.linspace(self.t, self.t + horizon_seconds, 8))
            if now_dist <= CFG.sensor_range or soon_dist <= CFG.sensor_range:
                active.append(d)
                detected.append(d.name)

        for k in range(CFG.horizon + 1):
            tt = self.t + k * self.controller.control_dt
            for d in active:
                i = self.moving_obstacles.index(d)
                b = 4 * i
                blocks[b:b + 3, k] = d.position(tt)
                blocks[b + 3, k] = d.radius + CFG.vehicle_radius + CFG.base_safety_margin
        return blocks, detected, horizon_seconds

    def plan(self, reason="scheduled"):
        start = self.x[:3].copy()
        margin = CFG.vehicle_radius + CFG.base_safety_margin

        active_moving = [
            d for d in self.moving_obstacles
            if self.dynamic_avoidance_enabled
            and np.linalg.norm(d.position(self.t) - start) <= CFG.sensor_range + 2.0
        ]

        if self.aurora_used and self.aurora_trace is not None:
            s_near, _ = self._polyline_projection(self.aurora_trace, start)
            rest_s = s_near + 10.0
            target_pt = self._point_at_arclength(self.aurora_trace, rest_s)

            blocked = False
            for p in self.aurora_trace[max(0, int(s_near)):min(len(self.aurora_trace), int(s_near) + 40)]:
                for s in STATIC:
                    if np.linalg.norm(p - s.center) < s.radius + margin:
                        blocked = True
                        break
                for d in active_moving:
                    if np.linalg.norm(p - d.position(self.t)) < d.radius + margin:
                        blocked = True
                        break
                if blocked:
                    break

            if blocked:
                detour, detour_times = build_3d_time_astar(
                    start, target_pt, BOUNDS, CFG.planning_grid, STATIC, active_moving, self.t,
                    time_step=CFG.planner_time_step, max_steps=CFG.planner_max_steps,
                    cruise_speed=CFG.cruise_speed, margin=margin,
                )
                detour, detour_times = simplify_timed_path(
                    detour, detour_times, STATIC, active_moving, margin=margin
                )
                s_idx = self._index_at_arclength(self.aurora_trace, rest_s)
                if s_idx < len(self.aurora_trace):
                    points = np.vstack([detour, self.aurora_trace[s_idx:]])
                else:
                    points = detour
            else:
                s_idx = self._index_at_arclength(self.aurora_trace, s_near)
                pts = self.aurora_trace[s_idx:]
                if len(pts) > 0:
                    points = np.vstack([start[None, :], pts])
                else:
                    points = np.vstack([start[None, :], self.goal[None, :]])

            times = np.linspace(self.t, self.t + len(points) * CFG.planner_time_step, len(points))
        else:
            points, times = build_3d_time_astar(
                start, self.goal, BOUNDS, CFG.planning_grid, STATIC, active_moving, self.t,
                time_step=CFG.planner_time_step, max_steps=CFG.planner_max_steps,
                cruise_speed=CFG.cruise_speed, margin=margin,
            )
            points, times = simplify_timed_path(points, times, STATIC, active_moving, margin=margin)
            points, times = simplify_timed_path(points, times, STATIC, active_moving, margin=margin)

        self.route = points
        self.route_times = times
        self.route_history.append(points.copy())
        self.replans += 1
        self.last_plan = self.t
        self.last_route_notice = f"{reason}: {len(points)} timed waypoints"


    def _path_geometry(self, points):
        points = np.asarray(points, dtype=float)
        key = id(points)
        cached = self._path_geometry_cache.get(key)
        if cached is not None and cached[0] is points:
            return cached[1:]
        if len(points) <= 1:
            ab = np.zeros((0, 3)); lens = np.zeros(0); cumulative = np.array([0.0]); den = np.zeros(0)
        else:
            ab = np.diff(points, axis=0)
            lens = np.linalg.norm(ab, axis=1)
            cumulative = np.concatenate(([0.0], np.cumsum(lens)))
            den = np.sum(ab * ab, axis=1)
        self._path_geometry_cache[key] = (points, ab, lens, cumulative, den)
        # Bound cache memory if repeated replans replace the route many times.
        if len(self._path_geometry_cache) > 12:
            oldest = next(iter(self._path_geometry_cache))
            if oldest != key:
                self._path_geometry_cache.pop(oldest, None)
        return ab, lens, cumulative, den

    def _polyline_projection(self, points, pos):
        """Vectorized closest-point projection onto a 3-D polyline."""
        points = np.asarray(points, dtype=float)
        pos = np.asarray(pos, dtype=float)
        if len(points) <= 1:
            return 0.0, float(np.linalg.norm(pos - points[0]))
        ab, lens, cumulative, den = self._path_geometry(points)
        a = points[:-1]
        alpha = np.divide(np.sum((pos - a) * ab, axis=1), den,
                          out=np.zeros_like(den), where=den > 1e-12)
        alpha = np.clip(alpha, 0.0, 1.0)
        nearest = a + alpha[:, None] * ab
        distances = np.linalg.norm(nearest - pos, axis=1)
        idx = int(np.argmin(distances))
        arc = float(cumulative[idx] + alpha[idx] * lens[idx])
        return arc, float(distances[idx])

    def _index_at_arclength(self, points, s):
        points = np.asarray(points, dtype=float)
        if len(points) <= 1:
            return 0
        _, _, cumulative, _ = self._path_geometry(points)
        return int(np.clip(np.searchsorted(cumulative, max(0.0, float(s)), side="left"), 0, len(points)-1))

    def _point_at_arclength(self, points, s):
        points = np.asarray(points, dtype=float)
        if len(points) == 1:
            return points[0].copy()
        ab, lens, cumulative, _ = self._path_geometry(points)
        remaining = float(np.clip(s, 0.0, cumulative[-1]))
        i = int(np.clip(np.searchsorted(cumulative, remaining, side="right") - 1, 0, len(points)-2))
        alpha = 0.0 if lens[i] < 1e-9 else float(np.clip((remaining - cumulative[i]) / lens[i], 0.0, 1.0))
        return points[i] + alpha * ab[i]

    def _route_target(self, lookahead=2.4):
        if self.route is None or len(self.route) == 0:
            return self.goal.copy()
        s_near, _ = self._polyline_projection(self.route, self.x[:3])
        return self._point_at_arclength(self.route, s_near + lookahead)

    def _reference_horizon(self):
        refs = np.zeros((4, CFG.horizon + 1), dtype=float)
        if self.route is None:
            target = self.goal.copy()
            yaw = math.atan2(target[1] - self.x[1], target[0] - self.x[0])
            refs[:] = np.array([*target, yaw])[:, None]
            return refs

        s_near, _ = self._polyline_projection(self.route, self.x[:3])
        # Preview farther along the spatial path, but do not force the AUV to
        # arrive at a timestamped waypoint faster than its dynamics allow.
        for k in range(CFG.horizon + 1):
            s1 = s_near + 2.4 + 0.42 * self.x[4] * (k + 1) * self.controller.control_dt
            s2 = s1 + 0.7
            p1 = self._point_at_arclength(self.route, s1)
            p2 = self._point_at_arclength(self.route, s2)
            yaw = math.atan2(p2[1] - p1[1], p2[0] - p1[0]) if np.linalg.norm(p2[:2] - p1[:2]) > 1e-6 else self.x[3]
            refs[:, k] = [p1[0], p1[1], p1[2], yaw]
        return refs

    def _predicted_collision(self):
        """Find the most dangerous moving object over the next few seconds."""
        if not self.dynamic_avoidance_enabled:
            return None
        best = None
        for d in self.moving_obstacles:
            if np.linalg.norm(d.position(self.t) - self.x[:3]) > CFG.sensor_range + 4.0:
                continue
            for j, tt in enumerate(np.linspace(self.t, self.t + 6.0, 25)):
                # Approximate where the AUV will be if it keeps current velocity.
                pred_auv = self.x[:3].copy()
                pred_auv[0] += (self.x[4] * math.cos(self.x[3]) - self.x[5] * math.sin(self.x[3])) * (tt - self.t)
                pred_auv[1] += (self.x[4] * math.sin(self.x[3]) + self.x[5] * math.cos(self.x[3])) * (tt - self.t)
                pred_auv[2] += self.x[6] * (tt - self.t)
                op = d.position(tt)
                clearance = float(np.linalg.norm(pred_auv - op) - d.radius - CFG.vehicle_radius)
                if best is None or clearance < best[0]:
                    best = (clearance, d, op, tt)
        return best

    def _safety_shield(self, tau):
        """Predictive safety correction for moving/static hazards and boundaries."""
        out = np.asarray(tau, dtype=float).copy()
        min_clearance = 1e9

        threat = self._predicted_collision()
        if threat is not None:
            clearance, d, op, tt = threat
            min_clearance = min(min_clearance, clearance)
            # Keep a predictive margin, but avoid a very large repulsion zone that
            # can trap a slow vehicle in front of a moving obstacle indefinitely.
            if clearance < 4.2:
                away = self.x[:3] - op
                away /= max(np.linalg.norm(away), 1e-9)
                desired_yaw = math.atan2(away[1], away[0])
                yaw_err = wrap_angle(desired_yaw - self.x[3])

                # Turn away from the predicted collision point and use depth as a
                # secondary escape direction. The closer the predicted collision,
                # the stronger the correction.
                strength = np.clip((4.2 - clearance) / 2.7, 0.0, 1.0)
                out[2] += 55.0 * strength * math.tanh(2.0 * yaw_err)
                out[1] += 48.0 * strength * math.tanh(1.5 * away[2])
                if clearance < 2.0:
                    out[0] -= 60.0 * strength

        nearest_static = None
        nearest_static_clear = 1e9
        for s in STATIC:
            clear = float(np.linalg.norm(s.center - self.x[:3]) - s.radius - CFG.vehicle_radius)
            if clear < nearest_static_clear:
                nearest_static_clear = clear
                nearest_static = s
        min_clearance = min(min_clearance, nearest_static_clear)

        if nearest_static is not None and nearest_static_clear < 2.8:
            away = self.x[:3] - nearest_static.center
            away /= max(np.linalg.norm(away), 1e-9)
            desired_yaw = math.atan2(away[1], away[0])
            yaw_err = wrap_angle(desired_yaw - self.x[3])
            strength = np.clip((2.8 - nearest_static_clear) / 1.8, 0.0, 1.0)
            out[2] += 50.0 * strength * math.tanh(2.0 * yaw_err)
            out[1] += 44.0 * strength * math.tanh(1.4 * away[2])
            if nearest_static_clear < 1.8:
                out[0] -= 55.0 * strength

        # Workspace/depth safety. This is deliberately independent of the planner.
        if self.x[1] < -16.0:
            out[2] += 18.0
        elif self.x[1] > 16.0:
            out[2] -= 18.0
        if self.x[2] < CFG.depth_floor:
            out[1] += 42.0
        elif self.x[2] > CFG.surface_limit and self.t > 9.0:
            out[1] -= 45.0

        return np.clip(out, -np.asarray(CFG.tau_max), np.asarray(CFG.tau_max)), min_clearance

    # ------------------------------------------------------------------
    # Sensor-state estimate and dynamics / execution loop
    # ------------------------------------------------------------------
    def _measure_state(self):
        """Return controller-facing state with optional measurement noise.

        The physics and collision metric retain the true simulated state. Noise is
        applied only to the state passed into the selected guidance/controller law.
        """
        measured = self.x.copy()
        if self.position_noise_m > 0.0:
            measured[:3] += self.sensor_rng.normal(0.0, self.position_noise_m, 3)
        if self.heading_noise_rad > 0.0:
            measured[3] = wrap_angle(measured[3] + self.sensor_rng.normal(0.0, self.heading_noise_rad))
        self.last_measurement = measured.copy()
        return measured

    def _deployment_control(self):
        # Hold launch X/Y and reach deployment depth smoothly.
        target = np.array([self.x[0], self.x[1], CFG.deployment_depth])
        refs = np.tile(np.array([*target, self.x[3]], dtype=float)[:, None], (1, CFG.horizon + 1))
        if self.frame % CFG.control_every == 0:
            observation = self._measure_state()
            blocks = np.zeros((4 * len(self.moving_obstacles), CFG.horizon + 1), dtype=float)
            for i in range(len(self.moving_obstacles)):
                blocks[4 * i + 3, :] = 1e6
            tau_nom, _ = self.controller_bank.solve(observation, refs, blocks)
            self.nominal_tau = tau_nom.copy()
            if self.controller_bank.mode == "nmpc":
                tau = tube_feedback(tau_nom, observation, self.nominal, np.asarray(CFG.tau_max, dtype=float))
            else:
                tau = tau_nom
            self.commanded_tau = np.asarray(tau, dtype=float).copy()
            return tau
        return self.commanded_tau.copy()

    def _mission_control(self):
        blocks, names, _ = self.current_obstacles()
        self.detected_names = names

        nearest_dyn = min(
            [np.linalg.norm(d.position(self.t) - self.x[:3]) - d.radius - CFG.vehicle_radius for d in self.moving_obstacles],
            default=999.0,
        ) if self.dynamic_avoidance_enabled else 999.0
        nearest_static = min(
            [np.linalg.norm(s.center - self.x[:3]) - s.radius - CFG.vehicle_radius for s in STATIC],
            default=999.0,
        )
        threat = min(nearest_dyn, nearest_static)

        need_plan = (
            self.route is None
            or (threat < 3.8 and self.t - self.last_plan > 5.0)
        )
        if need_plan:
            reason = "initial" if self.route is None else "obstacle threat"
            self.plan(reason)

        refs = self._reference_horizon()
        if self.frame % CFG.control_every == 0:
            # Keep the nominal state evolving between control solves so uncertainty
            # can produce a meaningful actual-versus-nominal tracking error.
            observation = self._measure_state()
            tau_nom, _ = self.controller_bank.solve(observation, refs, blocks)
            self.nominal_tau = tau_nom.copy()
            if self.controller_bank.mode == "nmpc":
                tau = tube_feedback(
                    tau_nom, observation, self.nominal,
                    np.asarray(CFG.tau_max, dtype=float),
                )
            else:
                tau = tau_nom
            tau, _ = self._safety_shield(tau)
        else:
            tau = self.commanded_tau.copy()
        return tau

    def step(self):
        if self.mission_complete:
            return

        self.current = sample_current(self.t) * self.current_scale
        self.dist = sample_disturbance(self.t) * self.disturbance_scale
        self.frame += 1

        deploy_depth_error = abs(float(self.x[2]) - CFG.deployment_depth)
        if self.t < 9.0 or (self.t < 20.0 and deploy_depth_error > 0.65):
            self.status = "DEPLOYING"
            tau = self._deployment_control()
        else:
            self.status = "MISSION"
            tau = self._mission_control()

        # Physical thruster slew-rate limit. The controller cannot instantaneously
        # realize a large change in force.
        self.commanded_tau = np.asarray(tau, dtype=float).copy()
        rate = np.asarray(CFG.tau_rate_max, dtype=float)
        tau_applied = self.last_applied_tau + np.clip(
            self.commanded_tau - self.last_applied_tau,
            -rate * CFG.dt,
            rate * CFG.dt,
        )
        tau_applied = np.clip(tau_applied, -np.asarray(CFG.tau_max), np.asarray(CFG.tau_max))
        # Log accelerations from the actual applied force/moment, not from the
        # requested command that may be changed by slew/magnitude limits.
        state_dot = dynamics(self.x, tau_applied, self.plant,
                             disturbance=self.dist, current=self.current)
        acc_u, acc_v, acc_w, acc_r = map(float, state_dot[4:8])

        # Real plant: parameter mismatch + unknown disturbance + current.
        self.x = rk4(
            self.x,
            tau_applied,
            self.plant,
            CFG.dt,
            disturbance=self.dist,
            current=self.current,
        )
        # Nominal model used by the tube-style correction.
        self.nominal = rk4(self.nominal, self.nominal_tau, self.nom, CFG.dt)
        self.last_applied_tau = tau_applied.copy()
        self.t += CFG.dt

        # Metrics
        ref = self._route_target() if self.route is not None else np.array([self.x[0], self.x[1], CFG.deployment_depth])
        track_error = float(np.linalg.norm(self.x[:3] - ref))
        self.max_track_error = max(self.max_track_error, track_error)

        clearances = []
        for s in STATIC:
            clearances.append(float(np.linalg.norm(self.x[:3] - s.center) - s.radius - CFG.vehicle_radius))
        for d in self.moving_obstacles:
            clearances.append(float(np.linalg.norm(self.x[:3] - d.position(self.t)) - d.radius - CFG.vehicle_radius))
        mc = min(clearances) if clearances else 999.0
        self.min_clearance = min(self.min_clearance, mc)
        if mc < 0.0:
            self.collisions += 1

        # Goal completion check: close enough in 3-D after the deployment phase.
        goal_error = float(np.linalg.norm(self.x[:3] - self.goal))
        if self.status == "MISSION" and goal_error <= 2.5:
            self.mission_complete = True
            self.status = "MISSION COMPLETE"

        self.rows.append([
            self.t,
            *self.x,
            acc_u, acc_v, acc_w, acc_r,
            *self.nominal_tau,
            *self.commanded_tau,
            *tau_applied,
            *self.current,
            *self.dist,
            track_error,
            mc,
            goal_error,
            self.replans,
            int(self.status == "DEPLOYING"),
            ", ".join(self.detected_names),
            self.controller_bank.mode,
            self.scenario,
            self.current_scale,
            self.disturbance_scale,
            int(self.dynamic_avoidance_enabled),
        ])

    # ------------------------------------------------------------------
    # 3-D visualisation
    # ------------------------------------------------------------------
    def _make_scene(self):
        self.renderer = vtk.vtkRenderer()
        self.renderer.SetBackground(0.003, 0.014, 0.035)
        self.renderer.SetBackground2(0.0, 0.18, 0.30)
        self.renderer.GradientBackgroundOn()
        # Improve translucent sensor cones, particles, bubbles and hazard rings.
        self.renderer.SetUseDepthPeeling(1)
        self.renderer.SetMaximumNumberOfPeels(8)
        self.renderer.SetOcclusionRatio(0.12)

        for pos, intensity, color in [
            ((-10, -14, 12), 1.55, (0.72, 0.88, 1.0)),
            ((22, 10, -1), 0.75, (0.38, 0.68, 0.92)),
            ((-30, 18, -12), 0.42, (0.36, 0.62, 0.78)),
        ]:
            l = vtk.vtkLight(); l.SetPosition(*pos); l.SetIntensity(intensity); l.SetColor(*color); self.renderer.AddLight(l)

        self.renderer.AddActor(seabed(BOUNDS, CFG.seed))
        self.renderer.AddActor(water_surface(BOUNDS))
        for a in light_beams(BOUNDS, 11, 31): self.renderer.AddActor(a)

        rng = np.random.default_rng(4)
        for c in reef_centers:
            for a in coral_cluster(c, 1.55, rng): self.renderer.AddActor(a)
        for c in [(-23,-2,-19.3),(-18,5,-19.1),(-14,-9,-19.0),(-8,11,-19.1),(1,5,-19.2),(4,-10,-19.0),(14,8,-19.0),(20,-7,-19.1),(25,1,-19.0)]:
            for a in sea_grass(c, rng.uniform(.8,1.35), rng): self.renderer.AddActor(a)
        for c in [(-20,12,-19),(-20,-10,-19),(1,-11,-19.1),(14,12,-19),(25,-11,-19)]:
            for a in rock_field(c, .9, 8, rng): self.renderer.AddActor(a)

        for a in wreck_ship([-2,-2.5,-18.6], 1.0): self.renderer.AddActor(a)
        for a in container([8.5,-1.5,-18.2], 1.0, 8): self.renderer.AddActor(a)
        for a in container([-5,9,-18.1], .9, -18): self.renderer.AddActor(a)
        for a in dynamite_cache([16.5,-.5,-18.6], 1.0): self.renderer.AddActor(a)
        for a in pipeline([1,12.2,-19], 22, -.12): self.renderer.AddActor(a)
        for a in pipeline([-18,3,-19.1], 17, .38): self.renderer.AddActor(a)
        for a in cable_bundle([13,-8,-18.8], 18, .10): self.renderer.AddActor(a)

        rng = np.random.default_rng(9)
        particles = [[rng.uniform(-29,29), rng.uniform(-17,17), rng.uniform(-20.5,-1.0)] for _ in range(1450)]
        self.renderer.AddActor(point_cloud(particles, (.72,.88,1.0,.10), 2))
        bubbles=[]
        for center in [(-13,-7),(-1,-4),(8,4),(19,-5),(24,9)]:
            for j in range(34):
                ang=j/34*2*math.pi; bubbles.append([center[0]+.58*math.cos(ang),center[1]+.58*math.sin(ang),-19.3+(j%17)*.76])
        self.renderer.AddActor(point_cloud(bubbles, (.77,.92,1.0,.17), 3))
        for i in range(18):
            pp=np.array([-25+(i*3.0)%50, -14+((i*7)%26), -3.5-((i*3)%11)])
            self.renderer.AddActor(fish_actor(pp, .7+.18*(i%3), (i%7)*.45))

        self.aurora_actor = line_actor(self.aurora_trace, (.55,.75,.95,.16), 2, dashed=True)
        self.renderer.AddActor(self.aurora_actor)
        self.launch_marker = sphere(self.x[:3], .55, (.12,.88,.98,.92))
        self.goal_marker = sphere(self.goal, .80, (.22,.98,.38,.92))
        self.renderer.AddActor(self.launch_marker); self.renderer.AddActor(self.goal_marker)

        self.auv = make_auv_actor(); self.renderer.AddActor(self.auv)
        self.moving_visuals={}; self.dynamic_labels={}
        for d in self.moving_obstacles:
            a=make_submersible_actor(d.radius/1.18) if ('Submersible' in d.name or 'Drone' in d.name) else make_debris_actor(d.radius/.95)
            self.renderer.AddActor(a); self.moving_visuals[d.name]=a
            label=vtk.vtkBillboardTextActor3D(); label.SetInput(d.name); label.GetTextProperty().SetFontSize(12); label.GetTextProperty().SetColor(.98,.60,.45); label.SetScale(.010); self.renderer.AddActor(label); self.dynamic_labels[d.name]=label

        self.path_actor=None; self.actual_actor=None; self.dynamic_actors=[]; self.detected_actors=[]

        self.hud_title=text_actor("AUTONOMOUS UNDERWATER VEHICLE  |  OBSTACLE AVOIDANCE MISSION",(18,855),20,(.94,.98,1),(.02,.05,.08),.88,True,True)
        self.hud_mode=text_actor("AUTO | 4 CONTROLLERS | 8-STATE MODEL",(895,855),11,(.42,1,.65),(.02,.05,.08),.88,True,True)
        self.hud_mission=text_actor("",(18,665),13)
        self.hud_telemetry=text_actor("",(930,650),11)
        self.hud_controller=text_actor("",(930,475),11)
        self.hud_obstacles=text_actor("",(930,300),11)
        self.hud_sensors=text_actor("",(18,48),12,(.74,.92,1),(.02,.05,.08),.78,True)
        self.hud_help=text_actor("SPACE Pause | C Cycle | 5 NMPC | 6 PID | 7 LOS-PID | 8 Robust-PD | O Obstacle awareness\n[ ] Current/disturbance | N Noise preset | 1 Overview | 2 Follow | 3 Free | 4 Top | S Screenshot | R Restart | ESC Exit",(18,12),10,(.65,.78,.86),(.02,.04,.06),.70,True)
        for ta in [self.hud_title,self.hud_mode,self.hud_mission,self.hud_telemetry,self.hud_controller,self.hud_obstacles,self.hud_sensors,self.hud_help]: self.renderer.AddViewProp(ta)

        self.window=vtk.vtkRenderWindow(); self.window.AddRenderer(self.renderer); self.window.SetSize(1480,900); self.window.SetWindowName("AUV Underwater Mission | Selectable Controllers")
        self.window.SetAlphaBitPlanes(1); self.window.SetMultiSamples(0)
        self.interactor=vtk.vtkRenderWindowInteractor(); self.interactor.SetRenderWindow(self.window); self.interactor.SetInteractorStyle(vtk.vtkInteractorStyleTrackballCamera()); self.interactor.AddObserver("KeyPressEvent",self.on_key)
        self.window.Render(); self._update_scene()

    def on_key(self,obj,evt):
        key=self.interactor.GetKeySym().lower()
        if key=='space': self.paused=not self.paused
        elif key=='r':
            self.interactor.TerminateApp(); self.__init__(headless=False, controller_mode=self.controller_bank.mode, scenario=self.scenario, current_scale=self.current_scale, disturbance_scale=self.disturbance_scale, seed=self.seed, position_noise_m=self.position_noise_m, heading_noise_deg=math.degrees(self.heading_noise_rad), dynamic_avoidance=self.dynamic_avoidance_enabled, reference_mode=self.reference_mode); self.run()
        elif key=='s': self.save_screenshot()
        elif key=='1': self.set_mission_view()
        elif key=='2': self.set_follow_view()
        elif key=='3': self.set_free_view()
        elif key=='4':
            self.camera_mode = 'top'
            cam=self.renderer.GetActiveCamera(); cam.SetPosition(0,-.5,42); cam.SetFocalPoint(0,0,-12); cam.SetViewUp(0,1,0); cam.SetViewAngle(50); self.renderer.ResetCameraClippingRange()
        elif key=='c':
            self.controller_bank.next_mode(); self.controller_mode = self.controller_bank.mode
            print(f"Controller: {CONTROLLER_LABELS[self.controller_mode]}")
        elif key in ('5', '6', '7', '8'):
            mode = {'5':'nmpc', '6':'pid', '7':'los-pid', '8':'robust-pd'}[key]
            self.controller_bank.set_mode(mode); self.controller_mode = mode
            print(f"Controller: {CONTROLLER_LABELS[self.controller_mode]}")
        elif key=='o':
            self.dynamic_avoidance_enabled = not self.dynamic_avoidance_enabled
            print('Moving-obstacle predictive awareness:', 'ON' if self.dynamic_avoidance_enabled else 'OFF (objects remain physically present)')
        elif key in ('bracketright', 'plus', 'equal', 'kp_add'):
            self.current_scale = min(3.0, self.current_scale + 0.15)
            self.disturbance_scale = min(3.0, self.disturbance_scale + 0.15)
        elif key in ('bracketleft', 'minus', 'kp_subtract'):
            self.current_scale = max(0.0, self.current_scale - 0.15)
            self.disturbance_scale = max(0.0, self.disturbance_scale - 0.15)
        elif key=='n':
            levels = [(0.0, 0.0), (0.05, 0.5), (0.15, 1.5)]
            current = (round(self.position_noise_m, 2), round(math.degrees(self.heading_noise_rad), 1))
            try: next_i = (levels.index(current) + 1) % len(levels)
            except ValueError: next_i = 0
            self.position_noise_m, hd = levels[next_i]
            self.heading_noise_rad = math.radians(hd)
            print(f"Controller-state noise: position std={self.position_noise_m:.2f} m, heading std={hd:.1f} deg")
        elif key=='escape': self.interactor.TerminateApp()

    def set_mission_view(self):
        self.camera_mode = 'overview'
        cam=self.renderer.GetActiveCamera(); cam.SetPosition(28,-38,2); cam.SetFocalPoint(-1,-1,-12); cam.SetViewUp(0,0,1); cam.SetViewAngle(48); self.renderer.ResetCameraClippingRange()

    def set_follow_view(self):
        self.camera_mode = 'follow'
        cam=self.renderer.GetActiveCamera(); p=self.x[:3]; f=np.array([math.cos(self.x[3]),math.sin(self.x[3]),0.0]); cam.SetPosition(*(p-13*f+np.array([0,0,5.5]))); cam.SetFocalPoint(*(p+6.5*f+np.array([0,0,-1]))); cam.SetViewUp(0,0,1); cam.SetViewAngle(46); self.renderer.ResetCameraClippingRange()

    def set_free_view(self):
        self.camera_mode = 'free'
        return

    def save_screenshot(self):
        if self.headless: return
        self.window.Render(); filt=vtk.vtkWindowToImageFilter(); filt.SetInput(self.window); filt.ReadFrontBufferOff(); filt.Update(); out=vtk.vtkPNGWriter(); out.SetFileName(str(RESULTS/'final_view.png')); out.SetInputConnection(filt.GetOutputPort()); out.Write()

    def _sensor_scan_geometry(self):
        p=self.x[:3]; yaw=self.x[3]; out=[]
        for a in np.linspace(-.95,.95,9):
            ang=yaw+a; end=p+np.array([math.cos(ang),math.sin(ang),0])*CFG.sensor_range; out.append(line_actor(np.vstack([p,end]),(.20,.84,.98,.12),1))
        end=p+np.array([math.cos(yaw),math.sin(yaw),0])*CFG.sensor_range; out.append(line_actor(np.vstack([p,end]),(.25,.92,1,.38),2)); return out

    def _update_scene(self):
        if self.headless: return
        for a in self.dynamic_actors+self.detected_actors: self.renderer.RemoveActor(a)
        self.dynamic_actors.clear(); self.detected_actors.clear()
        if self.path_actor is not None: self.renderer.RemoveActor(self.path_actor)
        if self.actual_actor is not None: self.renderer.RemoveActor(self.actual_actor)
        if self.route is not None:
            self.path_actor=line_actor(self.route,(.18,1,.48,.96),5); self.renderer.AddActor(self.path_actor)
        if self.rows:
            arr=np.asarray(self.rows,dtype=object); xyz=np.asarray(arr[:,1:4],float); self.actual_actor=line_actor(xyz,(.24,.55,1,.98),4); self.renderer.AddActor(self.actual_actor)

        for d in self.moving_obstacles:
            p=d.position(self.t); self.moving_visuals[d.name].SetPosition(*p); self.dynamic_labels[d.name].SetPosition(*(p+np.array([0,0,d.radius+.45])))
            trail=np.asarray([d.position(tt) for tt in np.linspace(max(0,self.t-9),self.t+.8,50)]); tr=line_actor(trail,(.95,.34,.18,.42),2,dashed=True); self.renderer.AddActor(tr); self.dynamic_actors.append(tr)
            pred=np.asarray([d.position(tt) for tt in np.linspace(self.t,self.t+6,28)]); pr=line_actor(pred,(1,.52,.32,.68),2,dashed=True); self.renderer.AddActor(pr); self.dynamic_actors.append(pr)
            if d.name in self.detected_names:
                ring=sphere(p,d.radius+.72,(.98,.12,.08,.14)); self.renderer.AddActor(ring); self.detected_actors.append(ring)
                future=d.position(self.t+3); predm=sphere(future,.34,(1,.45,.16,.62)); self.renderer.AddActor(predm); self.detected_actors.append(predm)

        cv=self.current
        if np.linalg.norm(cv)>1e-5:
            end=self.x[:3]+np.asarray(cv)*22; ar=line_actor(np.vstack([self.x[:3],end]),(.18,.80,.96,.62),4); self.renderer.AddActor(ar); self.dynamic_actors.append(ar); hd=sphere(end,.18,(.18,.80,.96,.62),16); self.renderer.AddActor(hd); self.dynamic_actors.append(hd)

        sp=vtk.vtkSphereSource(); sp.SetCenter(*self.x[:3]); sp.SetRadius(CFG.sensor_range); sp.SetThetaResolution(32); sp.SetPhiResolution(20); sp.Update(); sa=actor(sp.GetOutput(),(.08,.46,.86,.038),.038,specular=0,power=1); self.renderer.AddActor(sa); self.detected_actors.append(sa)
        for ray in self._sensor_scan_geometry(): self.renderer.AddActor(ray); self.detected_actors.append(ray)
        yaw=self.x[3]; nose=self.x[:3]+np.array([math.cos(yaw),math.sin(yaw),0])*2.4; fend=nose+np.array([math.cos(yaw),math.sin(yaw),-.04])*8.5; cb=line_actor(np.vstack([nose,fend]),(.76,.94,.98,.38),5); self.renderer.AddActor(cb); self.dynamic_actors.append(cb)

        if self.camera_mode == 'follow':
            p=self.x[:3]; f=np.array([math.cos(self.x[3]),math.sin(self.x[3]),0.0]); cam=self.renderer.GetActiveCamera(); cam.SetPosition(*(p-13*f+np.array([0,0,5.5]))); cam.SetFocalPoint(*(p+6.5*f+np.array([0,0,-1]))); cam.SetViewUp(0,0,1)
            self.renderer.ResetCameraClippingRange()

        self.auv.SetPosition(*self.x[:3]); self.auv.SetOrientation(0,0,math.degrees(self.x[3]))
        goal_error=float(np.linalg.norm(self.x[:3]-self.goal)); detections=', '.join(self.detected_names) if self.detected_names else 'none'
        nearest_dyn=min([np.linalg.norm(d.position(self.t)-self.x[:3])-d.radius-CFG.vehicle_radius for d in self.moving_obstacles],default=999.)
        nearest_static=min([np.linalg.norm(s.center-self.x[:3])-s.radius-CFG.vehicle_radius for s in STATIC],default=999.)
        predicted=self._predicted_collision(); ttc='--'; risk='LOW'
        if predicted is not None:
            pc,_,_,pt=predicted; ttc=f'{max(0,pt-self.t):.1f} s'; risk='HIGH' if pc<1.8 else ('MED' if pc<3.5 else 'LOW')
        self.hud_mode.SetInput('AUTO  |  '+CONTROLLER_LABELS[self.controller_bank.mode].upper()+'  |  8-STATE REDUCED AUV MODEL')
        self.hud_mission.SetInput('MISSION STATUS\n'+f'Mode            {self.status}\nMission time    {self.t:6.1f} s\nReplans         {self.replans:4d}\nGoal error      {goal_error:6.2f} m\nGoal            ({self.goal[0]:.1f}, {self.goal[1]:.1f}, {self.goal[2]:.1f})\nRoute           {"ACTIVE" if self.route is not None else "SEARCHING"}')
        self.hud_telemetry.SetInput('AUV TELEMETRY\n'+f'Position        ({self.x[0]:6.2f}, {self.x[1]:6.2f}, {self.x[2]:6.2f}) m\nDepth           {-self.x[2]:6.2f} m\nSurge u         {self.x[4]:+5.2f} m/s\nSway v          {self.x[5]:+5.2f} m/s\nHeave w         {self.x[6]:+5.2f} m/s\nYaw             {math.degrees(self.x[3]):+5.1f} deg\nCurrent         ({self.current[0]:+.2f}, {self.current[1]:+.2f}) m/s')
        self.hud_controller.SetInput('CONTROLLER OUTPUT\n'+CONTROLLER_LABELS[self.controller_bank.mode]+(' + tube-style correction' if self.controller_bank.mode == 'nmpc' else '')+'\n'+f'Longitudinal F {self.last_applied_tau[0]:+6.2f} N\nVertical F      {self.last_applied_tau[1]:+6.2f} N\nYaw moment      {self.last_applied_tau[2]:+6.2f} N m\nTracked error   {self.max_track_error:6.2f} m\nMin clearance   {self.min_clearance:6.2f} m\nForce limits    {CFG.tau_max[0]:.0f}/{CFG.tau_max[1]:.0f}/{CFG.tau_max[2]:.0f}\nSlew limits     {CFG.tau_rate_max[0]:.0f}/{CFG.tau_rate_max[1]:.0f}/{CFG.tau_rate_max[2]:.0f} N/s\nCurrent/disturb {self.current_scale:.2f}/{self.disturbance_scale:.2f}\nPosition noise  {self.position_noise_m:.2f} m')
        self.hud_obstacles.SetInput('OBSTACLE DETECTION\n'+f'Detected         {len(self.detected_names):2d}\nMoving objects   {sum("Moving" in n or "Submersible" in n or "Drone" in n for n in self.detected_names):2d}\nStatic clearance {nearest_static:6.2f} m\nDynamic clearance {nearest_dyn:6.2f} m\nPredicted TTC    {ttc}\nCollision risk   {risk}\nReplanning       {"ACTIVE" if self.route is not None else "SEARCHING"}\nTargets: {", ".join(self.detected_names[:2]) or "none"}\n         {self.detected_names[2] if len(self.detected_names)>2 else ""}')
        self.hud_sensors.SetInput(f'SENSORS | SONAR {CFG.sensor_range:.0f} m | MOVING-OBJECT AWARENESS {"ON" if self.dynamic_avoidance_enabled else "OFF"} | REFERENCE {"AURORA-DERIVED" if self.aurora_used else "DEMO"} | PATHS: green planned / blue actual / orange predicted')
        self.window.Render()

    # ------------------------------------------------------------------
    # Execution / logs
    # ------------------------------------------------------------------
    def run(self):
        self.set_mission_view()
        self.interactor.Initialize()
        self.window.Render()
        last_render = time.perf_counter()

        while self.interactor.GetDone() == 0 and self.t < CFG.total_time and not self.mission_complete:
            if not self.paused:
                self.step()
                self._update_scene()
            else:
                time.sleep(0.05)
            self.interactor.ProcessEvents()
            if time.perf_counter() - last_render < 0.03:
                time.sleep(0.008)
            last_render = time.perf_counter()

        self.save_screenshot()
        self.write_logs()

    def write_logs(self):
        fields = [
            "time", "X", "Y", "Z", "psi", "u", "v", "w", "r",
            "acc_u", "acc_v", "acc_w", "acc_r",
            "tau_nom_X", "tau_nom_Z", "tau_nom_N",
            "tau_cmd_X", "tau_cmd_Z", "tau_cmd_N",
            "tauX", "tauZ", "tauN", "curX", "curY", "curZ", "dX", "dY", "dZ",
            "track_error", "min_clearance", "goal_error", "replans", "deployment", "detected",
            "controller_mode", "scenario", "current_scale", "disturbance_scale", "dynamic_avoidance_enabled"
        ]
        with open(RESULTS / "mission_log.csv", "w", newline="", encoding="utf-8") as f:
            wr = csv.writer(f)
            wr.writerow(fields)
            wr.writerows(self.rows)

        final_goal_error = float(np.linalg.norm(self.x[:3] - self.goal))
        summary = (
            "AUV Autonomous Underwater Moving-Obstacle Mission\n"
            "==============================================\n"
            f"AURORA source: {self.aurora_msg}\n"
            f"AURORA used for run: {self.aurora_used}\n"
            f"Final status: {self.status}\n"
            f"Final time: {self.t:.2f} s\n"
            f"Final position (X,Y,Z): {self.x[0]:.3f}, {self.x[1]:.3f}, {self.x[2]:.3f}\n"
            f"Goal: {self.goal.tolist()}\n"
            f"Final goal error: {final_goal_error:.3f} m\n"
            f"Replans: {self.replans}\n"
            f"Minimum clearance margin: {self.min_clearance:.3f} m\n"
            f"Maximum reference tracking error: {self.max_track_error:.3f} m\n"
            f"Collision samples: {self.collisions}\n"
            f"Moving obstacles: {', '.join(d.name for d in self.moving_obstacles)}\n"
            f"Robustness: plant parameter mismatch + bounded current + unknown force disturbance\n"
            f"Controller: {CONTROLLER_LABELS[self.controller_bank.mode]}\n"
            f"Scenario: {self.scenario}\n"
            f"Reference mode: {self.reference_mode}\n"
            f"Current scale: {self.current_scale:.3f}\n"
            f"Disturbance scale: {self.disturbance_scale:.3f}\n"
            f"Position measurement noise std: {self.position_noise_m:.3f} m\n"
            f"Heading measurement noise std: {math.degrees(self.heading_noise_rad):.3f} deg\n"
            f"Moving-obstacle predictive awareness: {self.dynamic_avoidance_enabled}\n"
        )
        (RESULTS / "mission_summary.txt").write_text(summary, encoding="utf-8")


def run_controller_comparison(args):
    """Repeat the same scenario with each controller and write comparable metrics/logs."""
    from pathlib import Path
    import csv as csv_module
    compare_dir = RESULTS / "controller_comparison"
    compare_dir.mkdir(exist_ok=True)
    rows = []
    for mode in ControllerBank.MODES:
        sim = Simulation(
            headless=True, controller_mode=mode, scenario=args.scenario,
            current_scale=args.current_scale, disturbance_scale=args.disturbance_scale,
            seed=args.seed, position_noise_m=args.position_noise,
            heading_noise_deg=args.heading_noise_deg,
            dynamic_avoidance=not args.disable_dynamic_avoidance, reference_mode=args.reference,
        )
        while sim.t < CFG.total_time and not sim.mission_complete:
            sim.step()
        sim.write_logs()
        shutil.copy2(RESULTS / "mission_log.csv", compare_dir / f"{mode}_mission_log.csv")
        goal_error = float(np.linalg.norm(sim.x[:3] - sim.goal))
        track_values = np.asarray([row[28] for row in sim.rows], dtype=float) if sim.rows else np.array([np.nan])
        rows.append({
            "controller": mode,
            "controller_label": CONTROLLER_LABELS[mode],
            "scenario": sim.scenario,
            "duration_s": round(sim.t, 3),
            "status": sim.status,
            "goal_error_m": round(goal_error, 4),
            "track_error_rms_m": round(float(np.sqrt(np.nanmean(track_values ** 2))), 4),
            "track_error_max_m": round(float(np.nanmax(track_values)), 4),
            "min_clearance_m": round(float(sim.min_clearance), 4),
            "collision_samples": int(sim.collisions),
            "replans": int(sim.replans),
            "aurora_reference_used": bool(sim.aurora_used),
        })
        print(f"{mode:9s} status={sim.status:16s} goal_error={goal_error:.3f} m min_clearance={sim.min_clearance:.3f} m")
    with open(compare_dir / "controller_comparison.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv_module.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader(); writer.writerows(rows)
    (compare_dir / "README.txt").write_text(
        "Controller comparison runs were executed with the same scenario settings and initial seed.\n"
        "Results are specific to this configuration and simulation model; they are not real-vehicle validation.\n"
        "Each controller log is saved separately alongside controller_comparison.csv.\n",
        encoding="utf-8"
    )
    print(f"Comparison written to: {compare_dir / 'controller_comparison.csv'}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Selectable-controller AUV moving-obstacle simulation")
    ap.add_argument("--headless", action="store_true", help="Run without VTK GUI and write result logs")
    ap.add_argument("--seconds", type=float, default=None, help="Override simulation duration")
    ap.add_argument("--controller", choices=ControllerBank.MODES, default="nmpc", help="Controller mode")
    ap.add_argument("--scenario", choices=tuple(SCENARIOS.keys()), default="nominal", help="Environment disturbance/obstacle-speed preset")
    ap.add_argument("--reference", choices=("auto", "aurora", "demo"), default="auto", help="Choose AURORA navigation export or built-in demonstration path")
    ap.add_argument("--sensor-range", type=float, default=None, help="Override simulated obstacle sensor range in metres")
    ap.add_argument("--cruise-speed", type=float, default=None, help="Override desired cruise speed in m/s")
    ap.add_argument("--planning-grid", type=float, default=None, help="Override 3-D A* grid resolution in metres")
    ap.add_argument("--current-scale", type=float, default=None, help="Override preset current scale, 0 to 3")
    ap.add_argument("--disturbance-scale", type=float, default=None, help="Override preset disturbance scale, 0 to 3")
    ap.add_argument("--position-noise", type=float, default=0.0, help="Controller-state position noise standard deviation in metres")
    ap.add_argument("--heading-noise-deg", type=float, default=0.0, help="Controller-state heading noise standard deviation in degrees")
    ap.add_argument("--seed", type=int, default=7, help="Random seed for measurement noise and visual scene")
    ap.add_argument("--disable-dynamic-avoidance", action="store_true", help="Disable moving-obstacle prediction in planning/control (objects remain in the scene)")
    ap.add_argument("--compare-controllers", action="store_true", help="Run all four controller modes headlessly and compare metrics")
    args = ap.parse_args()

    if args.seconds is not None:
        CFG.total_time = max(CFG.dt, float(args.seconds))
    CFG.seed = int(args.seed)
    if args.current_scale is not None and not 0.0 <= args.current_scale <= 3.0:
        ap.error("--current-scale must be between 0 and 3")
    if args.disturbance_scale is not None and not 0.0 <= args.disturbance_scale <= 3.0:
        ap.error("--disturbance-scale must be between 0 and 3")
    if args.position_noise < 0 or args.heading_noise_deg < 0:
        ap.error("measurement noise values must be non-negative")
    if args.sensor_range is not None:
        if args.sensor_range <= 0: ap.error("--sensor-range must be positive")
        CFG.sensor_range = float(args.sensor_range)
    if args.cruise_speed is not None:
        if args.cruise_speed <= 0: ap.error("--cruise-speed must be positive")
        CFG.cruise_speed = float(args.cruise_speed)
    if args.planning_grid is not None:
        if args.planning_grid <= 0: ap.error("--planning-grid must be positive")
        CFG.planning_grid = float(args.planning_grid)

    if args.compare_controllers:
        CFG.total_time = CFG.total_time if args.seconds is not None else 20.0
        run_controller_comparison(args)
    else:
        sim = Simulation(
            headless=args.headless, controller_mode=args.controller, scenario=args.scenario,
            current_scale=args.current_scale, disturbance_scale=args.disturbance_scale,
            seed=args.seed, position_noise_m=args.position_noise,
            heading_noise_deg=args.heading_noise_deg,
            dynamic_avoidance=not args.disable_dynamic_avoidance, reference_mode=args.reference,
        )
        if args.headless:
            while sim.t < CFG.total_time and not sim.mission_complete:
                sim.step()
            sim.write_logs()
            print(sim.aurora_msg)
            print(f"controller={CONTROLLER_LABELS[sim.controller_bank.mode]}")
            print(f"scenario={sim.scenario}")
            print(f"status={sim.status}")
            print(f"final={sim.x[:3]}")
            print(f"goal={sim.goal}")
            print(f"goal_error={np.linalg.norm(sim.x[:3]-sim.goal):.3f}")
            print(f"replans={sim.replans}")
            print(f"min_clearance={sim.min_clearance:.3f}")
            print(f"collisions={sim.collisions}")
        else:
            sim.run()
