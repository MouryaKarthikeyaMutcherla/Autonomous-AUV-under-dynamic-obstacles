from __future__ import annotations
from dataclasses import dataclass
import heapq
import math
import numpy as np


@dataclass
class Sphere:
    name: str
    center: np.ndarray
    radius: float
    kind: str = "static"

    def collides(self, p, margin=0.0):
        return float(np.linalg.norm(np.asarray(p) - self.center)) <= self.radius + margin


@dataclass
class MovingSphere:
    name: str
    start: np.ndarray
    velocity: np.ndarray
    radius: float
    phase: float = 0.0
    wobble: float = 0.6
    active_duration: float | None = None

    def position(self, t: float) -> np.ndarray:
        raw_t = max(float(t) + self.phase, 0.0)
        tt = min(raw_t, self.active_duration) if self.active_duration is not None else raw_t
        p = self.start + self.velocity * tt
        p = p.copy()
        p[2] += self.wobble * np.sin(0.23 * tt + self.phase)
        return p

    def predicted(self, t0, horizon, dt):
        return [self.position(t0 + i * dt) for i in range(horizon + 1)]


def segment_hits_spheres(a, b, spheres, margin):
    a, b = np.asarray(a, float), np.asarray(b, float)
    ab = b - a
    den = float(np.dot(ab, ab))
    for s in spheres:
        q = a if den < 1e-9 else a + np.clip(np.dot(s.center - a, ab) / den, 0.0, 1.0) * ab
        if np.linalg.norm(q - s.center) <= s.radius + margin:
            return True
    return False


def build_3d_astar(start, goal, bounds, step, static_spheres, dynamic_spheres=None, t0=0.0, horizon=8, dt=0.8, margin=2.1):
    """Fast 3-D A* against the static underwater structure map."""
    lo = np.array([bounds[0][0], bounds[1][0], bounds[2][0]], dtype=float)
    hi = np.array([bounds[0][1], bounds[1][1], bounds[2][1]], dtype=float)
    start = np.asarray(start, float)
    goal = np.asarray(goal, float)

    def key(p):
        return tuple(np.round((np.asarray(p) - lo) / step).astype(int))

    def pos(k):
        return lo + np.array(k, dtype=float) * step

    sk, gk = key(start), key(goal)
    dirs = [(dx, dy, dz) for dx in (-1, 0, 1) for dy in (-1, 0, 1) for dz in (-1, 0, 1) if (dx, dy, dz) != (0, 0, 0)]

    def blocked(k):
        p = pos(k)
        if np.any(p < lo) or np.any(p > hi):
            return True
        return any(np.linalg.norm(p - s.center) <= s.radius + margin for s in static_spheres)

    # Grid endpoints can land slightly inside an inflated object. Move vertically to a nearby free cell.
    if blocked(sk):
        sx, sy, sz = sk
        for dz in range(-5, 6):
            kk = (sx, sy, sz + dz)
            if not blocked(kk):
                sk = kk
                break
    if blocked(gk):
        gx, gy, gz = gk
        for dz in range(-5, 6):
            kk = (gx, gy, gz + dz)
            if not blocked(kk):
                gk = kk
                break

    def h(k):
        return math.dist(k, gk)

    openq = [(h(sk), 0.0, sk)]
    gscore = {sk: 0.0}
    came = {}
    seen = set()

    while openq:
        _, gc, cur = heapq.heappop(openq)
        if cur in seen:
            continue
        seen.add(cur)
        if cur == gk:
            path = [cur]
            while cur in came:
                cur = came[cur]
                path.append(cur)
            path.reverse()
            out = np.array([pos(k) for k in path], dtype=float)
            out[0] = start
            out[-1] = goal
            return out

        for d in dirs:
            nxt = (cur[0] + d[0], cur[1] + d[1], cur[2] + d[2])
            if blocked(nxt):
                continue
            c = math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
            ng = gc + c
            if ng < gscore.get(nxt, 1e30):
                gscore[nxt] = ng
                came[nxt] = cur
                heapq.heappush(openq, (ng + h(nxt), ng, nxt))

    return np.array([start, goal], dtype=float)


def timed_segment_clear(a, b, ta, tb, static_spheres, dynamic_spheres, margin, samples=8):
    """Check a moving AUV segment against static and moving spherical obstacles."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    for j in range(samples + 1):
        alpha = j / float(samples)
        p = a + alpha * (b - a)
        t = ta + alpha * (tb - ta)
        for s in static_spheres:
            if np.linalg.norm(p - s.center) <= s.radius + margin:
                return False
        for d in dynamic_spheres:
            if np.linalg.norm(p - d.position(t)) <= d.radius + margin:
                return False
    return True


def path_conflict(points, t0, static_spheres, dynamic_spheres, cruise_speed, margin, samples=8):
    """Return the first predicted moving obstacle conflict on a route."""
    points = np.asarray(points, float)
    if len(points) < 2:
        return None
    t = float(t0)
    for i in range(len(points) - 1):
        a, b = points[i], points[i + 1]
        seg_len = float(np.linalg.norm(b - a))
        tb = t + max(seg_len / max(cruise_speed, 1e-3), 0.25)
        for d in dynamic_spheres:
            for j in range(samples + 1):
                alpha = j / float(samples)
                p = a + alpha * (b - a)
                tt = t + alpha * (tb - t)
                clear = float(np.linalg.norm(p - d.position(tt)) - d.radius)
                if clear <= margin:
                    return {"segment": i, "obstacle": d, "point": p, "time": tt, "clearance": clear}
        t = tb
    return None


def dynamic_detour(points, t0, static_spheres, dynamic_spheres, bounds, cruise_speed, margin):
    """Add a local 3-D detour around the first predicted moving-object conflict."""
    conflict = path_conflict(points, t0, static_spheres, dynamic_spheres, cruise_speed, margin)
    if conflict is None:
        # Route is already safe for predicted moving-object motion.
        times = [float(t0)]
        for i in range(1, len(points)):
            times.append(times[-1] + np.linalg.norm(points[i] - points[i - 1]) / max(cruise_speed, 1e-3))
        return np.asarray(points, float), np.asarray(times, float), None

    d = conflict["obstacle"]
    pcol = np.asarray(conflict["point"], float)
    tcol = float(conflict["time"])
    op = d.position(tcol)

    # Candidate escape directions: lateral, vertical and diagonal. Keep them
    # outside the dynamic obstacle and static structures.
    axes = [
        np.array([1, 0, 0], float), np.array([-1, 0, 0], float),
        np.array([0, 1, 0], float), np.array([0, -1, 0], float),
        np.array([0, 0, 1], float), np.array([0, 0, -1], float),
    ]
    candidates = []
    avoid_radius = d.radius + margin + 1.5
    for axis in axes:
        for mag in (avoid_radius, avoid_radius + 2.0):
            candidates.append(op + axis * mag)
    # Stronger perpendicular options based on the moving object's horizontal velocity.
    vh = np.array([d.velocity[0], d.velocity[1], 0.0], float)
    if np.linalg.norm(vh) > 1e-5:
        vh /= np.linalg.norm(vh)
        perp = np.array([-vh[1], vh[0], 0.0])
        for mag in (avoid_radius, avoid_radius + 2.5):
            candidates.append(op + perp * mag)
            candidates.append(op - perp * mag)

    lo = np.array([bounds[0][0], bounds[1][0], bounds[2][0]], float)
    hi = np.array([bounds[0][1], bounds[1][1], bounds[2][1]], float)
    candidates = [np.minimum(np.maximum(c, lo + margin), hi - margin) for c in candidates]

    seg_i = conflict["segment"]
    a = points[seg_i]
    tail = points[seg_i + 1:]
    prefix = list(points[:seg_i + 1])
    best = None
    for c in candidates:
        tc = t0 + sum(np.linalg.norm(points[i] - points[i - 1]) / max(cruise_speed, 1e-3) for i in range(1, seg_i + 1))
        tc += np.linalg.norm(c - a) / max(cruise_speed, 1e-3)
        # Candidate must be clear on the way to the detour and from detour to goal.
        if not timed_segment_clear(a, c, conflict["time"] - 4.0, tc, static_spheres, dynamic_spheres, margin, samples=10):
            continue
        if len(tail):
            ttail = tc
            ok = True
            for j in range(len(tail)):
                next_p = tail[j]
                tnext = ttail + np.linalg.norm(next_p - (c if j == 0 else tail[j - 1])) / max(cruise_speed, 1e-3)
                if not timed_segment_clear(c if j == 0 else tail[j - 1], next_p, ttail, tnext, static_spheres, dynamic_spheres, margin, samples=10):
                    ok = False
                    break
                ttail = tnext
            if not ok:
                continue
        cost = np.linalg.norm(c - a) + (np.linalg.norm(tail[-1] - c) if len(tail) else 0.0)
        clear_score = np.linalg.norm(c - op) - d.radius
        score = cost - 1.8 * clear_score
        if best is None or score < best[0]:
            best = (score, c)

    if best is None:
        return np.asarray(points, float), np.array([t0 + i / max(cruise_speed, 1e-3) for i in range(len(points))]), conflict

    detour = best[1]
    new_points = np.vstack([np.asarray(prefix, float), detour, tail])
    # Remove immediate duplicates.
    keep = [0]
    for i in range(1, len(new_points)):
        if np.linalg.norm(new_points[i] - new_points[keep[-1]]) > 0.3:
            keep.append(i)
    new_points = new_points[keep]

    times = [float(t0)]
    for i in range(1, len(new_points)):
        times.append(times[-1] + np.linalg.norm(new_points[i] - new_points[i - 1]) / max(cruise_speed, 1e-3))
    return new_points, np.asarray(times, float), conflict


def simplify_timed_path(points, times, static_spheres, dynamic_spheres, margin=2.2):
    """Remove redundant waypoints while preserving timed collision clearance."""
    if len(points) <= 2:
        return np.asarray(points, float), np.asarray(times, float)
    out_p = [points[0]]
    out_t = [times[0]]
    i = 0
    while i < len(points) - 1:
        chosen = i + 1
        for j in range(len(points) - 1, i + 1, -1):
            if timed_segment_clear(points[i], points[j], times[i], times[j], static_spheres, dynamic_spheres, margin):
                chosen = j
                break
        out_p.append(points[chosen])
        out_t.append(times[chosen])
        i = chosen
    return np.asarray(out_p, float), np.asarray(out_t, float)


def build_3d_time_astar(start, goal, bounds, step, static_spheres, dynamic_spheres, t0, time_step=0.9, max_steps=150, cruise_speed=0.62, margin=2.2):
    """Compatibility helper: fast static A* + moving-obstacle detour."""
    p = build_3d_astar(start, goal, bounds, step, static_spheres, [], t0, margin=margin)
    p, times, _ = dynamic_detour(p, t0, static_spheres, dynamic_spheres, bounds, cruise_speed, margin)
    return p, times
