Place the AURORA dataset/sample navigation files here.
The program searches recursively for CSV navigation files.
Do not rename or modify the original dataset just for this project; point/copy the folder here instead.
