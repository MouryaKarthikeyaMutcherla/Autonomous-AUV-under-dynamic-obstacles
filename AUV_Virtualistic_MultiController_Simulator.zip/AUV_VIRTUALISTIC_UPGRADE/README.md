# AUV Virtual Mission Simulator — Selectable Controllers Edition

This is an upgraded, Windows-friendly Python/VTK simulation for studying AUV guidance, route planning, and obstacle-aware control. It keeps the project's detailed underwater VTK scene and adds four selectable controllers, three environment presets, optional controller-state sensor noise, interactive disturbance adjustment, a controller-comparison mode, and model-consistent result plots.

## What is actually implemented

### Vehicle model
- **Eight-state reduced 3-D model:** `[X, Y, Z, psi, u, v, w, r]`.
- Position in the world frame, yaw, body surge/sway/heave velocity, and yaw rate.
- Nonlinear damping and motion-coupling terms, nominal/plant parameter mismatch, simulated currents, and bounded generalized-force disturbances.
- Fourth-order Runge–Kutta (RK4) state integration.
- Applied input magnitude limits and rate-of-change limits.

This is **not a full six-degree-of-freedom model**. The state does not contain roll, pitch, roll rate, or pitch rate. The directly commanded generalized inputs are longitudinal (surge) force, vertical (heave) force, and yaw moment. The project does not independently command lateral force or roll/pitch moments.

### Four controller modes
1. `nmpc` — lightweight finite-horizon predictive action search. It uses a small candidate-action set rather than a general-purpose nonlinear optimizer, followed by a tube-style feedback correction and the common safety shield.
2. `pid` — cascaded PID-style tracking for speed, heading, and depth.
3. `los-pid` — line-of-sight path guidance with PID-style speed, yaw, and depth loops.
4. `robust-pd` — damped inverse-dynamics PD with a bounded disturbance-rejection term. This is a practical heuristic, not a formal robust-stability guarantee.

All controller modes pass through the project's safety-processing and common force/rate constraints. The safety shield is a simulation heuristic, not a formally verified collision-avoidance guarantee.

### Environment options
- `calm`: lower current/disturbance scale and slower moving objects.
- `nominal`: configured baseline.
- `rough`: higher currents/disturbance and faster moving objects.
- Optional position and heading measurement noise applied to the **controller-facing state estimate**. The simulation's plant state, world map, route planner, and clearance metrics still use the simulator's internal state; this is therefore a limited sensor-noise experiment, not a complete noisy-perception model.
- Option to disable moving-obstacle predictive awareness for comparison. The moving objects remain present in the simulated environment.

### Navigation data handling
The loader prioritizes navigation/GPS-like exports (such as `data/aurora/navigation.txt`) and excludes multibeam/echosounder/index files from navigation-track selection. The reference track is smoothed and mapped into the visualization's local scene envelope so it fits the simulation. The supplied navigation text does not include depth, so the reference uses a fixed nominal depth for its 3-D display. This AURORA-derived trace is contextual reference data; it is **not** a measured AUV dynamics ground truth, and its mapped coordinates should not be interpreted as a metrically faithful geographic reconstruction.

## Run on Windows

Install Python 3.10+ and run from this folder in Command Prompt or PowerShell:

```powershell
py -m pip install -r requirements.txt
py main.py
```

Or double-click `RUN_AUV_SIM.bat`. Add options after the batch filename when launching it from a terminal.

### Interactive keys
- `SPACE`: pause / resume
- `C`: cycle through controller modes
- `5`: predictive NMPC-style controller
- `6`: PID controller
- `7`: LOS-PID controller
- `8`: Robust-PD controller
- `O`: toggle moving-obstacle predictive awareness (objects remain physically present)
- `[` / `]` (or minus/plus): decrease / increase current and disturbance scales
- `N`: cycle controller-state noise presets
- `1`: overview camera; `2`: AUV follow camera; `3`: free camera; `4`: top view
- `S`: save screenshot to `results/final_view.png`
- `R`: restart mission with the current controller/scenario settings
- `ESC`: exit

## Command-line examples

```powershell
# Default interactive simulation
py main.py

# Select a controller and environment preset
py main.py --controller pid --scenario calm
py main.py --controller los-pid --scenario rough
py main.py --controller robust-pd --scenario nominal

# Short headless validation run
py main.py --headless --seconds 30 --controller nmpc

# Add measurement noise to the state supplied to the controller
py main.py --headless --seconds 30 --controller pid --position-noise 0.05 --heading-noise-deg 0.5

# Override scenario scales (allowed range 0 to 3)
py main.py --headless --seconds 30 --current-scale 1.4 --disturbance-scale 1.2

# Run all four modes with the same configured scenario and compare logged metrics
py main.py --headless --compare-controllers --seconds 24
```

`RUN_CONTROLLER_COMPARISON.bat` runs the last example on Windows. Each controller's log is saved in `results/controller_comparison/`, with aggregate metrics in `controller_comparison.csv`.

## Included validation run

A packaged nominal comparison was run with all four controller modes. All four reached the simulator's goal-completion condition in that run. The recorded metrics are in `results/controller_comparison/controller_comparison.csv`; a human-readable summary is in `results/controller_comparison/CONTROLLER_COMPARISON_SUMMARY.txt` and a chart is in `results/controller_comparison.png`.

These are single-run simulated results. In that comparison, final goal error ranged from about 2.46 m to 2.50 m; minimum sampled clearance ranged from about 1.31 m to 4.48 m; no sampled collisions were recorded. The different clearances should not be treated as a statistical controller ranking without repeated trials. The selected AURORA-derived reference is smoothed and rescaled to the local scene and does not provide ground-truth vehicle dynamics.

## Result files
- `results/mission_log.csv` — state, acceleration, controller output, applied forces/moment, current, disturbances, tracking error and clearance metrics.
- `results/mission_summary.txt` — run settings and final summary.
- `results/sixdof_all_in_one.png` — combined implemented-state dashboard; filename retained for compatibility, but the title explicitly says eight-state model.
- `results/controller_nmpc_vs_corrected_applied.png` — raw/base command, after feedback/safety processing, and applied command.
- `results/controller_net_correction.png` — difference between the base command and post-processing command.
- `results/controller_force_and_moment.png` — longitudinal force (N), vertical force (N), and yaw moment (N·m).
- `results/controller_tracking_and_clearance.png` — tracking/goal error and sampled obstacle clearance.
- `results/controller_comparison.png` — generated after a comparison run.

Regenerate plots at any time with:

```powershell
py plot_final_project.py
```

## How to interpret results
The mission log describes a configured simulation run, not real-vehicle validation. A zero sampled collision count is not a guarantee of continuous-time or real-world safety. The tube-style correction and obstacle shield are not formally verified. Use repeated runs across controller modes/scenarios for comparisons, and avoid claiming a real-world accuracy percentage without independent ground-truth vehicle measurements.
