from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from config import CFG

@dataclass
class AUVParams:
    # Table I of the 2020 TASE paper.
    m11: float = 21.5
    m22: float = 26.5
    m33: float = 26.5
    m44: float = 8.0
    Xu: float = -70.0
    Yv: float = -100.0
    Zw: float = -100.0
    Nr: float = -50.0
    Xu_abs: float = -100.0
    Yv_abs: float = -200.0
    Zw_abs: float = -200.0
    Nr_abs: float = -100.0
    W: float = 176.6
    B: float = 181.2

    @property
    def M(self):
        return np.array([self.m11, self.m33, self.m44], dtype=float)


def wrap_angle(a):
    return (a + np.pi) % (2.0 * np.pi) - np.pi


def dynamics(x: np.ndarray, tau: np.ndarray, p: AUVParams, disturbance=None, current=None):
    """8-state 3-D underactuated model following TASE 2020 equations (1a)-(1h).

    x = [X,Y,Z,psi,u,v,w,r]. Z is positive upward; displayed depth = -Z.
    """
    X, Y, Z, psi, u, v, w, r = x
    tauX, tauZ, tauN = tau
    disturbance = np.zeros(3) if disturbance is None else np.asarray(disturbance, dtype=float)
    current = np.zeros(3) if current is None else np.asarray(current, dtype=float)

    dx = np.zeros(8, dtype=float)
    dx[0] = u*np.cos(psi) - v*np.sin(psi) + current[0]
    dx[1] = u*np.sin(psi) + v*np.cos(psi) + current[1]
    dx[2] = w + current[2]
    dx[3] = r
    dx[4] = (p.m22*v*r + p.Xu*u + p.Xu_abs*u*abs(u) + tauX + disturbance[0]) / p.m11
    dx[5] = (-p.m11*u*r + p.Yv*v + p.Yv_abs*v*abs(v) + disturbance[1]) / p.m22
    dx[6] = ((p.W-p.B) + p.Zw*w + p.Zw_abs*w*abs(w) + tauZ + disturbance[2]) / p.m33
    dx[7] = ((p.m11-p.m22)*u*v + p.Nr*r + p.Nr_abs*r*abs(r) + tauN) / p.m44
    return dx


def rk4(x, tau, p, dt, disturbance=None, current=None):
    f = lambda s: dynamics(s, tau, p, disturbance=disturbance, current=current)
    k1 = f(x)
    k2 = f(x + 0.5*dt*k1)
    k3 = f(x + 0.5*dt*k2)
    k4 = f(x + dt*k3)
    y = x + (dt/6.0)*(k1 + 2*k2 + 2*k3 + k4)
    y[3] = wrap_angle(y[3])
    return y


def sample_current(t):
    """Slow, spatially varying current used as a bounded environmental disturbance."""
    return np.array([
        0.10 + 0.08*np.sin(0.07*t),
        0.06*np.cos(0.05*t + 0.7),
        0.018*np.sin(0.11*t),
    ])


def sample_disturbance(t):
    
    return np.array([
        1.8*np.sin(0.21*t+0.3),
        1.2*np.cos(0.17*t-0.5),
        1.0*np.sin(0.13*t+1.1),
    ])


def plant_params():
    p = AUVParams()
    p.m11 *= 1.0 + 0.10
    p.m22 *= 1.0 - 0.12
    p.m33 *= 1.0 + 0.18
    p.m44 *= 1.0 + 0.30
    p.Xu_abs *= 1.0 + 0.20
    p.Yv_abs *= 1.0 - 0.18
    p.Zw_abs *= 1.0 + 0.22
    p.Nr_abs *= 1.0 - 0.25
    return p
