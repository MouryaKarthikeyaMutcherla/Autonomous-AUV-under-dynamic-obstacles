from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from config import CFG

@dataclass
class AUVParams:
    # Baseline coefficients from the project's simplified 2020 TASE-inspired model.
    # Added roll/pitch inertias, damping and restoring terms are explicit engineering
    # assumptions for this 6-DOF extension and must be identified/validated for a real vehicle.
    m11: float = 21.5
    m22: float = 26.5
    m33: float = 26.5
    m44: float = 8.0       # yaw inertia used by legacy model
    m55: float = 7.5       # roll inertia (assumed)
    m66: float = 9.0       # pitch inertia (assumed)
    Xu: float = -70.0
    Yv: float = -100.0
    Zw: float = -100.0
    Nr: float = -50.0
    Kp: float = -16.0      # roll-rate damping (assumed)
    Mq: float = -18.0      # pitch-rate damping (assumed)
    Xu_abs: float = -100.0
    Yv_abs: float = -200.0
    Zw_abs: float = -200.0
    Nr_abs: float = -100.0
    Kp_abs: float = -8.0
    Mq_abs: float = -9.0
    W: float = 176.6
    B: float = 181.2
    roll_restore: float = 22.0  # N m/rad, assumed passive hydrostatic restoring
    pitch_restore: float = 24.0 # N m/rad, assumed passive hydrostatic restoring

    @property
    def M(self):
        return np.array([self.m11, self.m33, self.m44], dtype=float)


def wrap_angle(a):
    return (a + np.pi) % (2.0 * np.pi) - np.pi


def dynamics(x: np.ndarray, tau: np.ndarray, p: AUVParams, disturbance=None, current=None):
    """12-state 6-DOF AUV model.

    State layout preserves the original simulator's first eight indices:
      x=[X,Y,Z,psi,u,v,w,r,phi,theta,p,q]
    X/Y/Z are inertial position; psi is yaw; u/v/w are body linear velocities;
    r is yaw rate; phi/theta are roll/pitch; p/q are roll/pitch rates.
    Z is positive upward (displayed depth=-Z). The vehicle has surge, heave,
    and yaw actuation; sway, roll, and pitch are passive/underactuated.

    This is a simplified coupled 6-DOF model, not a vehicle-specific CFD model.
    Roll/pitch inertia, damping and restoring coefficients are assumed parameters.
    """
    x = np.asarray(x, dtype=float)
    if x.size == 8:  # compatibility for external calls using the old model
        x = np.r_[x, 0.0, 0.0, 0.0, 0.0]
    if x.size != 12:
        raise ValueError(f"6-DOF dynamics expects 12 states; received {x.size}")
    X,Y,Z,psi,u,v,w,r,phi,theta,p_rate,q_rate = x
    tauX,tauZ,tauN = np.asarray(tau, dtype=float)
    disturbance = np.zeros(3) if disturbance is None else np.asarray(disturbance, dtype=float)
    current = np.zeros(3) if current is None else np.asarray(current, dtype=float)

    # Body-to-inertial rotation, ZYX Euler convention.
    cp,sp=np.cos(phi),np.sin(phi); ct,st=np.cos(theta),np.sin(theta); cy,sy=np.cos(psi),np.sin(psi)
    R=np.array([[cy*ct, cy*st*sp-sy*cp, cy*st*cp+sy*sp],
                [sy*ct, sy*st*sp+cy*cp, sy*st*cp-cy*sp],
                [-st,   ct*sp,             ct*cp]], dtype=float)
    earth_vel=R @ np.array([u,v,w])

    # Body angular rates -> ZYX Euler angle rates; protect the pitch singularity.
    ct_safe=np.copysign(max(abs(ct), 1e-4), ct if ct != 0 else 1.0)
    tan_theta=st/ct_safe
    phi_dot=p_rate + q_rate*sp*tan_theta + r*cp*tan_theta
    theta_dot=q_rate*cp - r*sp
    psi_dot=(q_rate*sp + r*cp)/ct_safe

    dx=np.zeros(12, dtype=float)
    dx[0:3]=earth_vel + current
    dx[3]=psi_dot
    # Translational dynamics with added-mass-style effective inertias and nonlinear drag.
    dx[4]=(p.m22*v*r + p.Xu*u + p.Xu_abs*u*abs(u) + tauX + disturbance[0])/p.m11
    dx[5]=(-p.m11*u*r + p.Yv*v + p.Yv_abs*v*abs(v) + disturbance[1])/p.m22
    dx[6]=((p.W-p.B) + p.Zw*w + p.Zw_abs*w*abs(w) + tauZ + disturbance[2])/p.m33
    dx[7]=((p.m11-p.m22)*u*v + p.Nr*r + p.Nr_abs*r*abs(r) + tauN)/p.m44
    # Passive roll/pitch response: angular damping + hydrostatic restoring moments.
    # Disturbance channels remain force-level; no fictional roll/pitch actuator is added.
    dx[8]=phi_dot
    dx[9]=theta_dot
    # Simplified cross-coupling terms keep the six-DOF rotational response coupled to translation.
    roll_coupling = (p.m22-p.m33)*v*w - 0.8*q_rate*r
    pitch_coupling = (p.m11-p.m33)*u*w + 0.8*p_rate*r
    dx[10]=(roll_coupling + p.Kp*p_rate + p.Kp_abs*p_rate*abs(p_rate) - p.roll_restore*np.sin(phi))/p.m55
    dx[11]=(pitch_coupling + p.Mq*q_rate + p.Mq_abs*q_rate*abs(q_rate) - p.pitch_restore*np.sin(theta))/p.m66
    return dx


def rk4(x, tau, p, dt, disturbance=None, current=None):
    x=np.asarray(x,dtype=float)
    f=lambda s: dynamics(s,tau,p,disturbance=disturbance,current=current)
    k1=f(x); k2=f(x+0.5*dt*k1); k3=f(x+0.5*dt*k2); k4=f(x+dt*k3)
    y=x+(dt/6.0)*(k1+2*k2+2*k3+k4)
    y[3]=wrap_angle(y[3]); y[8]=wrap_angle(y[8]); y[9]=wrap_angle(y[9])
    return y


def sample_current(t):
    return np.array([0.10+0.08*np.sin(0.07*t),0.06*np.cos(0.05*t+0.7),0.018*np.sin(0.11*t)])


def sample_disturbance(t):
    return np.array([1.8*np.sin(0.21*t+0.3),1.2*np.cos(0.17*t-0.5),1.0*np.sin(0.13*t+1.1)])


def plant_params():
    p=AUVParams()
    p.m11*=1.10; p.m22*=0.88; p.m33*=1.18; p.m44*=1.30; p.m55*=1.12; p.m66*=0.92
    p.Xu_abs*=1.20; p.Yv_abs*=0.82; p.Zw_abs*=1.22; p.Nr_abs*=0.75
    p.Kp_abs*=1.15; p.Mq_abs*=0.90
    return p
