from __future__ import annotations
import math
import numpy as np

from .dynamics import AUVParams, rk4, wrap_angle


class RobustNMPC:
    """Fast receding-horizon nonlinear controller for the interactive simulation.

    The implementation keeps the project academically traceable to the 2020
    tube-based NMPC structure: a nominal nonlinear AUV model is previewed over a
    finite horizon, input limits are respected, and an offline-style stabilizing
    tube correction is applied to the disturbed plant. A small action search is
    used instead of a heavyweight general-purpose nonlinear optimizer so the 3-D
    scene stays interactive on a normal student laptop.
    """

    def __init__(self, params: AUVParams, dt=0.12, horizon=8, control_interval=6):
        self.p = params
        self.dt = float(dt)
        self.N = int(horizon)
        self.control_interval = max(1, int(control_interval))
        self.control_dt = self.dt * self.control_interval
        self.tau_max = np.array([140.0, 100.0, 60.0], dtype=float)
        self.tau_rate = np.array([22.0, 16.0, 12.0], dtype=float)
        self.prev = np.zeros(3, dtype=float)

    def _model_inverse(self, x, target):
        """Convert position/heading targets into a nonlinear thrust suggestion."""
        X, Y, Z, psi, u, v, w, r = np.asarray(x, dtype=float)
        target = np.asarray(target, dtype=float)

        dx, dy, dz = target[0] - X, target[1] - Y, target[2] - Z
        desired_yaw = math.atan2(dy, dx)
        yaw_err = wrap_angle(desired_yaw - psi)

        # Slow down while turning and as the target is reached. This keeps the
        # predictive controller from driving through the final waypoint.
        planar_dist = float(np.hypot(dx, dy))
        speed_factor = float(np.clip(planar_dist / 3.0, 0.0, 1.0))
        u_des = 0.74 * speed_factor * max(0.20, math.cos(yaw_err))
        u_des = float(np.clip(u_des, 0.0, 0.76))
        du = 3.6 * (u_des - u)
        tau_x = self.p.m11 * du - self.p.m22 * v * r - self.p.Xu * u - self.p.Xu_abs * u * abs(u)

        # Strong but deliberately damped yaw regulation. Since sway is unactuated,
        # heading is the main lateral steering mechanism. A bounded PD term avoids
        # the oscillatory inverse-dynamics behaviour that can appear when the drag
        # terms change sign around r=0.
        tau_n = 44.0 * yaw_err - 24.0 * r
        tau_n += -(self.p.m11 - self.p.m22) * u * v

        w_des = float(np.clip(0.9 * dz, -0.52, 0.52))
        dw = 3.0 * (w_des - w)
        tau_z = self.p.m33 * dw - (self.p.W - self.p.B) - self.p.Zw * w - self.p.Zw_abs * w * abs(w)

        return np.clip(np.array([tau_x, tau_z, tau_n]), -self.tau_max, self.tau_max)

    def _predict_score(self, x0, tau, refs, obstacle_blocks):
        x = np.asarray(x0, dtype=float).copy()
        track = 0.0
        min_clearance = 1e9
        for k in range(min(self.N, refs.shape[1] - 1)):
            x = rk4(x, tau, self.p, self.dt)
            epos = x[:3] - refs[:3, k + 1]
            eyaw = wrap_angle(x[3] - refs[3, k + 1])
            track += float(epos @ epos) + 5.0 * eyaw * eyaw + 0.15 * float(np.dot(tau, tau))
            for oi in range(obstacle_blocks.shape[0] // 4):
                b = 4 * oi
                q = obstacle_blocks[b:b + 3, k + 1]
                safe = float(obstacle_blocks[b + 3, k + 1])
                d = float(np.linalg.norm(x[:3] - q) - safe)
                min_clearance = min(min_clearance, d)
                if d < 1.5:
                    track += 9000.0 * (1.5 - d) ** 2
                elif d < 4.0:
                    track += 55.0 * (4.0 - d) ** 2
        return min_clearance, track

    def solve(self, x0, refs, obstacle_blocks):
        x0 = np.asarray(x0, dtype=float)
        refs = np.asarray(refs, dtype=float)
        obstacle_blocks = np.asarray(obstacle_blocks, dtype=float)

        # Evaluate the nominal action plus smooth alternatives. The best candidate
        # is the action whose nonlinear preview gets closest to the reference while
        # maintaining the largest predicted clearance from moving obstacles.
        base = self._model_inverse(x0, refs[:3, 0])
        candidates = [base]
        base_clear, _ = self._predict_score(x0, base, refs, obstacle_blocks)
        if base_clear < 1.2:
            # Only use a few evasive candidates in a genuine near-term conflict.
            # The ordinary case stays on the mission route instead of being
            # repeatedly pushed around by distant obstacles.
            for off in ((0, 0, +22), (0, 0, -22), (0, +18, 0), (0, -18, 0)):
                candidates.append(np.clip(base + np.array(off, dtype=float), -self.tau_max, self.tau_max))

        best = base.copy()
        best_cost = 1e30
        best_clear = -1e30
        for cand in candidates:
            mc, cost = self._predict_score(x0, cand, refs, obstacle_blocks)
            # Clearance dominates only when it is genuinely low; otherwise tracking wins.
            penalty = 0.0 if mc >= 3.0 else 180.0 * (3.0 - mc) ** 2
            score = cost + penalty
            if score < best_cost:
                best_cost = score
                best_clear = mc
                best = cand.copy()

        # Apply the practical thruster slew limits from the project configuration.
        max_delta = self.tau_rate * self.control_dt
        best = self.prev + np.clip(best - self.prev, -max_delta, max_delta)
        best = np.clip(best, -self.tau_max, self.tau_max)
        self.prev = best.copy()
        return best, True


def tube_feedback(tau_nom, x_actual, x_nom, tau_max):
    """Simplified tube-style correction using actual/nominal state error.

    Position error is rotated into body-axis longitudinal/lateral components;
    since the model is underactuated, lateral error mainly requests a yaw change.
    This is a heuristic feedback law, not a formally certified invariant tube.
    """
    xa = np.asarray(x_actual, dtype=float)
    xn = np.asarray(x_nom, dtype=float)
    tau = np.asarray(tau_nom, dtype=float).copy()
    de = xa[:3] - xn[:3]
    psi = float(xa[3])
    longitudinal_err = math.cos(psi) * de[0] + math.sin(psi) * de[1]
    lateral_err = -math.sin(psi) * de[0] + math.cos(psi) * de[1]
    vel_err = xa[4:8] - xn[4:8]
    yaw_err = wrap_angle(xa[3] - xn[3])
    tau[0] -= 5.0 * longitudinal_err + 8.0 * vel_err[0]
    tau[1] -= 11.0 * de[2] + 6.5 * vel_err[2]
    tau[2] -= 9.0 * yaw_err + 3.5 * vel_err[3] + 2.0 * lateral_err
    return np.clip(tau, -np.asarray(tau_max, dtype=float), np.asarray(tau_max, dtype=float))
