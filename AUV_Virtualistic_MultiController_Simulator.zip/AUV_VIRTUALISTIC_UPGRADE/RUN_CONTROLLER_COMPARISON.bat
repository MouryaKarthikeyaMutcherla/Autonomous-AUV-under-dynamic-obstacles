@echo off
setlocal
cd /d "%~dp0"
py -c "import numpy, scipy, pandas, vtk, matplotlib" >nul 2>&1
if errorlevel 1 (
    echo Installing simulation dependencies...
    py -m pip install -r requirements.txt
    if errorlevel 1 (pause & exit /b 1)
)
echo Comparing NMPC-style, PID, LOS-PID and Robust-PD modes over the configured mission (up to 150 simulated seconds)...
py main.py --headless --compare-controllers --seconds 150 --scenario nominal --reference auto
if errorlevel 1 (echo Controller comparison failed. & pause & exit /b 1)
py plot_final_project.py
pause
