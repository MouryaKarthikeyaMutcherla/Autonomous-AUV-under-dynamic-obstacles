# AUV Autonomous Underwater Mission — Enhanced Python Simulator

This package is the upgraded version of the original AUV moving-obstacle simulator. The mathematical simulation loop is preserved; the VTK visualization has been upgraded into a richer underwater mission-control scene.

## Main capabilities

**AUV and dynamics**
- 12-state simplified 6-DOF AUV model: X/Y/Z, roll/pitch/yaw, surge/sway/heave and roll/pitch/yaw rates.
- Underactuated control remains surge force, heave force and yaw moment; sway/roll/pitch are passive dynamics.
- Nonlinear dynamics with model mismatch between nominal controller model and plant.
- Current and bounded unknown force disturbances.
- RK4 state propagation.
- Generalized force/torque saturation and slew-rate limits.

**Autonomy**
- Timed 3-D path planning around static obstacles.
- Moving-obstacle detection inside simulated sensing range.
- Future-position prediction for moving objects.
- Online route replanning when predicted clearance becomes unsafe.
- Finite-horizon nonlinear predictive control.
- Practical tube-style state feedback around the nominal trajectory.
- Independent predictive safety shield.

**Enhanced underwater visualization**
- Detailed AUV body: pressure hull, nose/tail, fins, sensor mast, camera dome, thruster pods and propeller hubs.
- Procedural seabed with lighting/shading.
- Coral formations and underwater vegetation.
- Rock fields.
- Wrecked ship with deck, masts, railings and portholes.
- Old shipping containers with structural ribs/rust patches.
- Pipelines and cable bundles.
- Hazard cache with warning beacon.
- Suspended underwater particles and bubble columns.
- Small non-colliding fish silhouettes for scene depth/life.
- Moving survey submersible, moving debris and passing submersible.
- Sonar-style sensing rays and sensing sphere.
- Camera/frustum beam.
- Current-flow vector.
- Reference/AURORA context path, planned path, actual path and moving-object prediction paths.
- Live mission, telemetry, controller and obstacle-detection HUD panels.

## 6-DOF model scope and validation

The six-DOF extension adds roll/pitch kinematics, angular-rate states, passive rotational dynamics, and six-DOF plots. Roll/pitch inertia, damping and hydrostatic restoring coefficients are explicit assumed values because the supplied project does not include vehicle-specific identification data. The existing three control inputs are retained; therefore roll and pitch are passive, not independently actuated. The plots are simulated model outputs, not experimental measurements. Validate/identify these coefficients before making quantitative claims about a real AUV.

## Important distinction

This is a **high-quality scientific VTK visualization**, not a photorealistic Unreal Engine/Stonefish render. The AUV controller, dynamics, obstacle prediction and replanning remain actual code executed by the simulator; the scene is the visual presentation layer.

## Run on Windows

Open PowerShell or Command Prompt in this folder.

### First run

```powershell
py -m pip install -r requirements.txt
```

### Start the simulator

```powershell
py main.py
```

or double-click:

```text
RUN_AUV_SIM.bat
```

The simulator stays open during the mission. The mission ends automatically when the goal is reached or the configured simulation time expires.

### Controls

```text
SPACE   Pause / resume
R       Restart mission
1       Overview camera
2       Follow AUV camera
3       Free/trackball camera
4       Top view
S       Save screenshot to results\final_view.png
ESC     Exit
```

The **follow camera continuously tracks the AUV** while mode 2 is active.

### Quick controller/dynamics validation without graphics

```powershell
py main.py --headless --seconds 150
```

Then regenerate the analysis plots (including six-DOF response figures):

```powershell
py plot_results.py
```

## Existing research/control basis

The implementation keeps the project's established control structure: nonlinear AUV dynamics, bounded disturbances/model mismatch, finite-horizon predictive control, tube-style correction, online obstacle updates and practical input limits. The moving-obstacle prediction layer remains the explicit project extension.

## AURORA

Place AURORA navigation CSV data under:

```text
data\aurora\
```

When no AURORA CSV is available, the program uses its clearly labelled built-in demonstration navigation track so the complete mission still runs.

## Sample visual

`PREVIEW_REAL_RENDER.png` in the project root is a real VTK render of the upgraded scene, generated from this code at a mission state with active route/obstacle information. It is a visual reference, not a claim of photorealistic rendering.

## Six-DOF response plots and accelerations

The upgraded model logs the six pose coordinates (X, Y, Z, roll, pitch, yaw), six body velocities (u, v, w, p, q, r), and the six body accelerations (udot, vdot, wdot, pdot, qdot, rdot) computed from the simulated plant dynamics. After a run, launch `PLOT_RESULTS.bat` on Windows or execute `py plot_results.py` from this folder. The plots are saved under `results/`. Acceleration values come from the assumed six-DOF model, not from experimental vehicle measurements.



## Combined six-DOF and controller figures

After a fresh run, `plot_final_project.py` generates exactly four figures: `sixdof_all_in_one.png` (3-by-2 combined six-DOF dashboard), `controller_nmpc_vs_corrected_applied.png`, `controller_net_correction.png`, and `controller_tracking_and_clearance.png`. Other older plots have been removed from `results/` and the plotting entry points now generate only these four figures. The controller implemented here is `RobustNMPC` plus a simplified tube-style feedback correction and safety shield; it is not a separately implemented standalone Tube MPC controller.

The mission log records nominal and requested controller commands (`tauNom*`, `tauReq*`) as well as applied commands (`tauX`, `tauZ`, `tauN`). The difference between requested and nominal command is labelled **net correction** because it may include safety-shield effects as well as tube-style feedback.
