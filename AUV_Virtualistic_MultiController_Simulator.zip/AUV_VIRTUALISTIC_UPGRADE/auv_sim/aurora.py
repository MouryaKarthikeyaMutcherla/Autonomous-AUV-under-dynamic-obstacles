from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d

ALIASES = {
    'x': ['position_x', 'pos_x', 'easting', 'utm_e', 'nav_x', 'x_m'],
    'y': ['position_y', 'pos_y', 'northing', 'utm_n', 'nav_y', 'y_m'],
    'depth': ['depth', 'depth_m', 'z', 'z_m', 'altitude', 'position_z', 'pos_z'],
    'heading': ['heading', 'yaw', 'psi', 'course', 'heading_deg', 'yaw_deg'],
    'time': ['seconds', 'time', 'timestamp', 'elapsed', 'time_s', 'sec'],
    'lat': ['latitude', 'lat'],
    'lon': ['longitude', 'lon', 'long'],
}


def _find_col(df_cols, options):
    cols = [str(c).strip() for c in df_cols]
    low_map = {c.lower(): c for c in cols}
    # Exact match first
    for opt in options:
        if opt in low_map:
            return low_map[opt]
    # Substring match (only for option strings longer than 1 char to avoid false positives like 'x' matching 'MagX')
    for c in cols:
        lc = c.lower()
        for opt in options:
            if len(opt) > 1 and opt in lc:
                return c
    return None


DEFAULT_DATA_DIR = Path(__file__).resolve().parent.parent / "data" / "aurora"


def load_aurora_track(root=None):
    if root is None:
        root = DEFAULT_DATA_DIR
    else:
        p = Path(root).resolve()
        if p.exists():
            root = p
        elif DEFAULT_DATA_DIR.exists():
            root = DEFAULT_DATA_DIR
        else:
            root = p
    files = []

    for ext in ['*.csv', '*.txt', '*.tsv', '*.dat']:
        files.extend(root.rglob(ext))
    candidates = []
    for f in sorted(set(files)):
        if '__MACOSX' in f.parts or f.name.startswith('.'):
            continue
        # Bathymetry/MBES index files often also contain Latitude/Longitude/Heading.
        # They are not the navigation-export file and must not win simply because
        # they contain more rows. Exclude them from the navigation-track candidates.
        lname = f.name.lower().replace('_', '-').replace(' ', '-')
        if any(token in lname for token in ('multi-beam', 'multibeam', 'echosounder', 'echo-sounder', 'mbes', 'bathymetry', 'index')):
            continue
        try:
            df = pd.read_csv(f, low_memory=False)
        except Exception:
            continue
        df.columns = [str(c).strip() for c in df.columns]
        cx, cy = _find_col(df.columns, ALIASES['x']), _find_col(df.columns, ALIASES['y'])
        cdep = _find_col(df.columns, ALIASES['depth'])
        clat, clon = _find_col(df.columns, ALIASES['lat']), _find_col(df.columns, ALIASES['lon'])
        if (cx and cy) or (clat and clon):
            candidates.append((len(df), f, df, cx, cy, cdep, clat, clon))
    if not candidates:
        return None, 'No AURORA navigation CSV/TXT found; using built-in demo track.'

    # Prefer clearly named navigation/GPS exports. Row count is only a tie-breaker,
    # not the primary selection criterion.
    def candidate_priority(item):
        count, f, df, cx, cy, cdep, clat, clon = item
        name = f.name.lower()
        preferred = any(token in name for token in ('navigation', 'nav-track', 'nav_track', 'gps', 'track'))
        return (int(preferred), count)

    for count, f, df, cx, cy, cdep, clat, clon in sorted(candidates, key=candidate_priority, reverse=True):
        if cx and cy:
            x = pd.to_numeric(df[cx], errors='coerce').to_numpy(dtype=float)
            y = pd.to_numeric(df[cy], errors='coerce').to_numpy(dtype=float)
        else:
            lat = pd.to_numeric(df[clat], errors='coerce').to_numpy(dtype=float)
            lon = pd.to_numeric(df[clon], errors='coerce').to_numpy(dtype=float)
            lat0, lon0 = np.nanmedian(lat), np.nanmedian(lon)
            x = (lon - lon0) * 111320.0 * np.cos(np.deg2rad(lat0))
            y = (lat - lat0) * 110540.0

        if cdep:
            zraw = pd.to_numeric(df[cdep], errors='coerce').to_numpy(dtype=float)
            med = np.nanmedian(zraw)
            depth = zraw - med if med != 0 else zraw
            z = -depth if np.nanmax(zraw) > 0 else depth
        else:
            z = np.full_like(x, -10.0)

        ch = _find_col(df.columns, ALIASES['heading'])
        if ch:
            h = pd.to_numeric(df[ch], errors='coerce').to_numpy(dtype=float)
            if np.nanmax(np.abs(h)) > 2 * np.pi + 0.5:
                h = np.deg2rad(h)
        else:
            dx = np.gradient(x)
            dy = np.gradient(y)
            h = np.arctan2(dy, dx)

        tcol = _find_col(df.columns, ALIASES['time'])
        if tcol and pd.api.types.is_numeric_dtype(df[tcol]):
            t = pd.to_numeric(df[tcol], errors='coerce').to_numpy(dtype=float)
            t = t - np.nanmin(t)
        else:
            t = np.arange(len(x), dtype=float)

        ok = np.isfinite(x) & np.isfinite(y) & np.isfinite(z) & np.isfinite(h) & np.isfinite(t)
        x, y, z, h, t = x[ok], y[ok], z[ok], h[ok], t[ok]
        if len(x) >= 20:
            # Normalize to a compact local mission envelope and smooth noisy sensor trajectory.
            # Scale smoothing to source length so high-rate exports are not treated
            # as if their sample spacing were identical to a small sample file.
            smooth_sigma = float(np.clip(len(x) / 900.0, 4.0, 36.0))
            sx = gaussian_filter1d(x, smooth_sigma)
            sy = gaussian_filter1d(y, smooth_sigma)
            sz = gaussian_filter1d(z, smooth_sigma)
            scale = max(np.ptp(sx), np.ptp(sy), 1.0)
            target_span = 42.0
            sx = (sx - np.mean(sx)) * target_span / scale
            sy = (sy - np.mean(sy)) * target_span / scale
            sz = np.clip(-9.0 + 0.25 * (sz - np.mean(sz)), -18.0, -5.0)
            h = np.unwrap(h)
            return {'x': sx, 'y': sy, 'z': sz, 'heading': h, 'time': t}, f'Using AURORA navigation track: {f}'

    return None, 'No valid candidate track could be parsed.'


def demo_track(n=800):
    t = np.linspace(0, 1, n)
    x = -24 + 50 * t
    y = -11 + 12 * np.sin(1.3 * np.pi * t) + 2.0 * np.sin(4 * np.pi * t)
    z = -7 - 10 * t + 0.8 * np.sin(3 * np.pi * t)
    h = np.unwrap(np.arctan2(np.gradient(y), np.gradient(x)))
    return {'x': x, 'y': y, 'z': z, 'heading': h, 'time': t}


def resample_track(track, n=1400):
    from scipy.interpolate import CubicSpline
    s = np.linspace(0, 1, len(track['x']))
    ss = np.linspace(0, 1, n)
    out = {}
    for k in ['x', 'y', 'z']:
        out[k] = CubicSpline(s, track[k])(ss)
    out['heading'] = np.unwrap(np.arctan2(np.gradient(out['y']), np.gradient(out['x'])))
    out['time'] = ss
    return out
