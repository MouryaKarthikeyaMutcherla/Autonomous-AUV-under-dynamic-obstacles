from dataclasses import dataclass


@dataclass
class SimConfig:
    # Physics / controller timing
    dt: float = 0.10
    horizon: int = 9
    control_every: int = 2
    total_time: float = 150.0

    # Perception / planning
    sensor_range: float = 18.0
    planning_grid: float = 2.5
    planner_time_step: float = 0.60
    planner_max_steps: int = 180
    cruise_speed: float = 0.70
    vehicle_radius: float = 1.0
    base_safety_margin: float = 1.35

    # Mission
    launch_point: tuple = (-26.0, -12.0, -0.8)
    deployment_depth: float = -7.0
    mission_goal: tuple = (24.0, 5.0, -14.0)
    depth_floor: float = -19.4
    surface_limit: float = -3.2

    # Velocity bounds from the 2020 paper's simulation envelope.
    u_max: float = 0.8
    v_max: float = 0.25
    w_max: float = 0.6
    r_max: float = 0.6

    # Generalized thrust/torque saturation from the 2020 paper's simulation.
    tau_max: tuple = (140.0, 100.0, 60.0)

    # Project-level generalized-force slew limits, inspired by the 2025 paper's
    # explicit thrust rate-of-change constraint. These are not the 2025 paper's
    # individual-thruster numbers, because our plant uses the 2020 generalized input.
    tau_rate_max: tuple = (50.0, 38.0, 30.0)

    # Robustness / model mismatch
    disturbance_bound: float = 3.5
    added_mass_uncertainty: float = 0.25
    rotational_uncertainty: float = 0.35
    seed: int = 7


CFG = SimConfig()
