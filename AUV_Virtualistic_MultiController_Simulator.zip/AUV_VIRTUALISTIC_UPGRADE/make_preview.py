"""Render a preview of the current simulator at an active mission state.
Run on a desktop, or under xvfb-run -a python make_preview.py on Linux.
"""
from pathlib import Path
from main import Simulation

sim = Simulation(headless=True, controller_mode="nmpc", scenario="nominal", reference_mode="auto")
for _ in range(320):
    sim.step()
    if sim.mission_complete:
        break
sim.headless = False
sim._make_scene()
sim.set_mission_view()
sim._update_scene()
sim.save_screenshot()
print(f"Saved {Path(__file__).resolve().parent / 'results' / 'final_view.png'}", flush=True)
# Some VTK/GL backends keep GUI event threads alive even after Finalize in a
# headless preview process. Force-stop this one-shot utility after the PNG is saved.
import os
os._exit(0)
