@echo off
setlocal
cd /d "%~dp0"
py -c "import numpy, scipy, pandas, vtk, matplotlib" >nul 2>&1
if errorlevel 1 (
    echo Installing simulation dependencies for the first run...
    py -m pip install -r requirements.txt
    if errorlevel 1 (
        echo Dependency installation failed.
        pause
        exit /b 1
    )
)
echo Starting AUV simulation. After the mission completes, press Esc to close the 3-D window.
py main.py
if errorlevel 1 (
    echo The simulation returned an error. Check the console output above.
    pause
    exit /b 1
)
echo.
echo Generating only the requested six-DOF and controller plots...
py plot_final_project.py
if errorlevel 1 echo Plot generation failed. Check results\mission_log.csv and the error above.
echo Requested figures are saved in the results folder.
pause
