from __future__ import annotations

import argparse
import csv
import math
import time
from pathlib import Path

import numpy as np
import vtk

from config import CFG
from auv_sim.aurora import demo_track, load_aurora_track, resample_track
from auv_sim.controller import RobustNMPC, tube_feedback
from auv_sim.dynamics import AUVParams, dynamics, plant_params, rk4, sample_current, sample_disturbance, wrap_angle
from auv_sim.planner import (
    MovingSphere,
    Sphere,
    build_3d_time_astar,
    simplify_timed_path,
)
from auv_sim.scene import (
    actor,
    coral_cluster,
    cube,
    dynamite_cache,
    line_actor,
    make_auv_actor,
    make_debris_actor,
    make_submersible_actor,
    point_cloud,
    seabed,
    water_surface,
    light_beams,
    sea_grass,
    rock_field,
    pipeline,
    cable_bundle,
    fish_actor,
    text_actor,
    sphere,
    container,
    wreck_ship,
)


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)

BOUNDS = ((-30.0, 30.0), (-18.0, 18.0), (-22.0, -2.0))


# -----------------------------------------------------------------------------
# Underwater world
# -----------------------------------------------------------------------------
# Collision geometry is deliberately simpler than the visual geometry. The
# controller plans against inflated spheres while the VTK scene shows natural
# looking coral, wreck, containers, rocks and a hazardous cache.
STATIC = []

reef_centers = [
    (-17.0, -5.0, -18.7),
    (-11.0, 6.0, -18.5),
    (3.5, 8.5, -18.8),
    (12.0, -8.0, -18.8),
    (21.0, 5.0, -18.7),
]
for i, c in enumerate(reef_centers):
    STATIC.append(Sphere(f"Coral Reef {i + 1}", np.array(c, float), 2.8, "reef"))

STATIC += [
    Sphere("Wrecked Ship", np.array([-2.0, -2.5, -18.0]), 4.6, "wreck"),
    Sphere("Wrecked Ship Bow", np.array([4.0, -2.3, -17.6]), 2.5, "wreck"),
    Sphere("Old Container A", np.array([8.5, -1.5, -18.1]), 2.7, "container"),
    Sphere("Old Container B", np.array([-5.0, 9.0, -18.0]), 2.4, "container"),
    Sphere("Hazard Cache", np.array([16.5, -0.5, -18.4]), 2.0, "hazard"),
]

for i, c in enumerate([
    (-24, 11, -19.0),
    (-20, -10, -19.0),
    (1.0, -10.5, -19.0),
    (15, 11, -18.9),
    (25, -10, -19.0),
]):
    STATIC.append(Sphere(f"Rock {i + 1}", np.array(c, float), 1.7, "rock"))


# Moving obstacles. Their motion is known to the simulation plant but only
# predicted when they enter the AUV's sensing region.
MOVING = [
    MovingSphere(
        "Moving Survey Drone",
        np.array([-13.0, -5.0, -10.5]),
        np.array([0.32, 0.20, 0.0]),
        1.15,
        0.0,
        wobble=0.55,
        active_duration=48.0,
    ),
    MovingSphere(
        "Moving Debris",
        np.array([11.0, -13.0, -12.2]),
        np.array([-0.18, 0.30, 0.0]),
        0.95,
        1.8,
        wobble=0.40,
        active_duration=58.0,
    ),
    MovingSphere(
        "Passing Submersible",
        np.array([25.0, 15.0, -14.0]),
        np.array([-0.28, -0.22, 0.0]),
        1.25,
        5.5,
        wobble=0.45,
        active_duration=68.0,
    ),
]


class Simulation:
    def __init__(self, headless=False):
        self.headless = bool(headless)
        self.t = 0.0
        self.frame = 0
        self.paused = False
        self.camera_mode = "overview"

        self.nom = AUVParams()
        self.plant = plant_params()

        # State layout: [X,Y,Z,psi,u,v,w,r,phi,theta,p,q].
        self.x = np.array([*CFG.launch_point, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=float)
        self.nominal = self.x.copy()
        self.current = np.zeros(3)
        self.dist = np.zeros(3)
        self.last_applied_tau = np.zeros(3)
        self.commanded_tau = np.zeros(3)
        self.nominal_tau = np.zeros(3)

        self.controller = RobustNMPC(self.nom, CFG.dt, CFG.horizon, CFG.control_every)

        self.goal = np.array(CFG.mission_goal, dtype=float)
        self.route = None
        self.route_times = None
        self.route_history = []
        self.replans = 0
        self.last_plan = -1e9
        self.status = "DEPLOYING"
        self.mission_complete = False

        self.min_clearance = 1e9
        self.max_track_error = 0.0
        self.collisions = 0
        self.rows = []
        self.detected_names = []
        self.last_route_notice = "No route yet"

        # AURORA track is used as a real navigation-reference/scene-context layer.
        # The actual raw dataset is not attached to this project, so the loader falls
        # back to a clearly labelled demonstration track until CSV data are supplied.
        tr, msg = load_aurora_track(ROOT / "data" / "aurora")
        if tr is None:
            tr = demo_track()
            self.aurora_used = False
        else:
            self.aurora_used = True
        self.aurora_msg = msg
        self.aurora_track = resample_track(tr, 1200)
        self.aurora_trace = self._make_aurora_ghost()

        if not self.headless:
            self._make_scene()

    # ------------------------------------------------------------------
    # AURORA context
    # ------------------------------------------------------------------
    def _make_aurora_ghost(self):
        p = np.c_[self.aurora_track["x"], self.aurora_track["y"], self.aurora_track["z"]]
        p[:, 2] = np.clip(p[:, 2], -18.0, -5.5)
        p -= p[0]
        p[:, 0] *= 0.72
        p[:, 1] *= 0.55
        p[:, 2] = -8.2 + 0.35 * p[:, 2]
        p += np.array([-23.0, -10.5, 0.0])
        return p

    # ------------------------------------------------------------------
    # Planning and prediction
    # ------------------------------------------------------------------
    def current_obstacles(self):
        # The controller only gets obstacles that are inside the simulated sensor
        # range. Unknown obstacles are effectively absent from its local map.
        blocks = np.zeros((4 * len(MOVING), CFG.horizon + 1), dtype=float)
        blocks[:, :] = 0.0
        for i in range(len(MOVING)):
            blocks[4 * i + 3, :] = 1e6

        detected = []
        horizon_seconds = CFG.horizon * self.controller.control_dt
        active = []
        for d in MOVING:
            now_dist = np.linalg.norm(d.position(self.t) - self.x[:3])
            soon_dist = min(np.linalg.norm(d.position(tt) - self.x[:3]) for tt in np.linspace(self.t, self.t + horizon_seconds, 8))
            if now_dist <= CFG.sensor_range or soon_dist <= CFG.sensor_range:
                active.append(d)
                detected.append(d.name)

        for k in range(CFG.horizon + 1):
            tt = self.t + k * self.controller.control_dt
            for d in active:
                i = MOVING.index(d)
                b = 4 * i
                blocks[b:b + 3, k] = d.position(tt)
                blocks[b + 3, k] = d.radius + CFG.vehicle_radius + CFG.base_safety_margin
        return blocks, detected, horizon_seconds

    def plan(self, reason="scheduled"):
        start = self.x[:3].copy()
        margin = CFG.vehicle_radius + CFG.base_safety_margin

        active_moving = [
            d for d in MOVING
            if np.linalg.norm(d.position(self.t) - start) <= CFG.sensor_range + 2.0
        ]
        points, times = build_3d_time_astar(
            start, self.goal, BOUNDS, CFG.planning_grid, STATIC, active_moving, self.t,
            time_step=CFG.planner_time_step, max_steps=CFG.planner_max_steps,
            cruise_speed=CFG.cruise_speed, margin=margin,
        )
        # One extra dynamic detour pass after simplification catches a conflict
        # created by smoothing/replanning without turning the planner into a heavy
        # 4-D search at every control step.
        points, times = simplify_timed_path(points, times, STATIC, active_moving, margin=margin)
        points, times = simplify_timed_path(points, times, STATIC, active_moving, margin=margin)

        self.route = points
        self.route_times = times
        self.route_history.append(points.copy())
        self.replans += 1
        self.last_plan = self.t
        self.last_route_notice = f"{reason}: {len(points)} timed waypoints"

    @staticmethod
    def _polyline_projection(points, pos):
        points = np.asarray(points, float)
        pos = np.asarray(pos, float)
        best_s = 0.0
        best_dist = 1e30
        cumulative = 0.0
        for i in range(len(points) - 1):
            a, b = points[i], points[i + 1]
            ab = b - a
            den = float(ab @ ab)
            alpha = 0.0 if den < 1e-12 else float(np.clip((pos - a) @ ab / den, 0.0, 1.0))
            q = a + alpha * ab
            d = float(np.linalg.norm(pos - q))
            if d < best_dist:
                best_dist = d
                best_s = cumulative + alpha * float(np.linalg.norm(ab))
            cumulative += float(np.linalg.norm(ab))
        return best_s, best_dist

    @staticmethod
    def _point_at_arclength(points, s):
        points = np.asarray(points, float)
        if len(points) == 1:
            return points[0].copy()
        remaining = max(float(s), 0.0)
        for i in range(len(points) - 1):
            seg = float(np.linalg.norm(points[i + 1] - points[i]))
            if remaining <= seg or i == len(points) - 2:
                a = 0.0 if seg < 1e-9 else remaining / seg
                a = np.clip(a, 0.0, 1.0)
                return points[i] + a * (points[i + 1] - points[i])
            remaining -= seg
        return points[-1].copy()

    def _route_target(self, lookahead=2.4):
        if self.route is None or len(self.route) == 0:
            return self.goal.copy()
        s_near, _ = self._polyline_projection(self.route, self.x[:3])
        return self._point_at_arclength(self.route, s_near + lookahead)

    def _reference_horizon(self):
        refs = np.zeros((4, CFG.horizon + 1), dtype=float)
        if self.route is None:
            target = self.goal.copy()
            yaw = math.atan2(target[1] - self.x[1], target[0] - self.x[0])
            refs[:] = np.array([*target, yaw])[:, None]
            return refs

        s_near, _ = self._polyline_projection(self.route, self.x[:3])
        # Preview farther along the spatial path, but do not force the AUV to
        # arrive at a timestamped waypoint faster than its dynamics allow.
        for k in range(CFG.horizon + 1):
            s1 = s_near + 2.4 + 0.42 * self.x[4] * (k + 1) * self.controller.control_dt
            s2 = s1 + 0.7
            p1 = self._point_at_arclength(self.route, s1)
            p2 = self._point_at_arclength(self.route, s2)
            yaw = math.atan2(p2[1] - p1[1], p2[0] - p1[0]) if np.linalg.norm(p2[:2] - p1[:2]) > 1e-6 else self.x[3]
            refs[:, k] = [p1[0], p1[1], p1[2], yaw]
        return refs

    def _predicted_collision(self):
        """Find the most dangerous moving object over the next few seconds."""
        best = None
        for d in MOVING:
            if np.linalg.norm(d.position(self.t) - self.x[:3]) > CFG.sensor_range + 4.0:
                continue
            for j, tt in enumerate(np.linspace(self.t, self.t + 6.0, 25)):
                # Approximate where the AUV will be if it keeps current velocity.
                pred_auv = self.x[:3].copy()
                pred_auv[0] += (self.x[4] * math.cos(self.x[3]) - self.x[5] * math.sin(self.x[3])) * (tt - self.t)
                pred_auv[1] += (self.x[4] * math.sin(self.x[3]) + self.x[5] * math.cos(self.x[3])) * (tt - self.t)
                pred_auv[2] += self.x[6] * (tt - self.t)
                op = d.position(tt)
                clearance = float(np.linalg.norm(pred_auv - op) - d.radius - CFG.vehicle_radius)
                if best is None or clearance < best[0]:
                    best = (clearance, d, op, tt)
        return best

    def _safety_shield(self, tau):
        """Predictive safety correction for moving/static hazards and boundaries."""
        out = np.asarray(tau, dtype=float).copy()
        min_clearance = 1e9

        threat = self._predicted_collision()
        if threat is not None:
            clearance, d, op, tt = threat
            min_clearance = min(min_clearance, clearance)
            if clearance < 6.0:
                away = self.x[:3] - op
                away /= max(np.linalg.norm(away), 1e-9)
                desired_yaw = math.atan2(away[1], away[0])
                yaw_err = wrap_angle(desired_yaw - self.x[3])

                # Turn away from the predicted collision point and use depth as a
                # secondary escape direction. The closer the predicted collision,
                # the stronger the correction.
                strength = np.clip((6.0 - clearance) / 4.0, 0.0, 1.0)
                out[2] += 55.0 * strength * math.tanh(2.0 * yaw_err)
                out[1] += 48.0 * strength * math.tanh(1.5 * away[2])
                if clearance < 2.0:
                    out[0] -= 60.0 * strength

        nearest_static = None
        nearest_static_clear = 1e9
        for s in STATIC:
            clear = float(np.linalg.norm(s.center - self.x[:3]) - s.radius - CFG.vehicle_radius)
            if clear < nearest_static_clear:
                nearest_static_clear = clear
                nearest_static = s
        min_clearance = min(min_clearance, nearest_static_clear)

        if nearest_static is not None and nearest_static_clear < 2.8:
            away = self.x[:3] - nearest_static.center
            away /= max(np.linalg.norm(away), 1e-9)
            desired_yaw = math.atan2(away[1], away[0])
            yaw_err = wrap_angle(desired_yaw - self.x[3])
            strength = np.clip((2.8 - nearest_static_clear) / 1.8, 0.0, 1.0)
            out[2] += 50.0 * strength * math.tanh(2.0 * yaw_err)
            out[1] += 44.0 * strength * math.tanh(1.4 * away[2])
            if nearest_static_clear < 1.8:
                out[0] -= 55.0 * strength

        # Workspace/depth safety. This is deliberately independent of the planner.
        if self.x[1] < -16.0:
            out[2] += 18.0
        elif self.x[1] > 16.0:
            out[2] -= 18.0
        if self.x[2] < CFG.depth_floor:
            out[1] += 42.0
        elif self.x[2] > CFG.surface_limit and self.t > 9.0:
            out[1] -= 45.0

        return np.clip(out, -np.asarray(CFG.tau_max), np.asarray(CFG.tau_max)), min_clearance

    # ------------------------------------------------------------------
    # Dynamics / execution loop
    # ------------------------------------------------------------------
    def _deployment_control(self):
        # Hold launch X/Y and reach deployment depth smoothly.
        target = np.array([self.x[0], self.x[1], CFG.deployment_depth])
        refs = np.tile(np.array([*target, self.x[3]], dtype=float)[:, None], (1, CFG.horizon + 1))
        if self.frame % CFG.control_every == 0:
            # 2020-paper-style receding-horizon reset: start the nominal prediction
            # from the measured state at every solve, while the real plant continues
            # to experience disturbances and model mismatch between solves.
            self.nominal = self.x.copy()
            tau, _ = self.controller.solve(self.nominal, refs, np.zeros((4 * len(MOVING), CFG.horizon + 1)))
            self.nominal_tau = tau.copy()
            return tau
        return self.commanded_tau.copy()

    def _mission_control(self):
        blocks, names, _ = self.current_obstacles()
        self.detected_names = names

        nearest_dyn = min(
            [np.linalg.norm(d.position(self.t) - self.x[:3]) - d.radius - CFG.vehicle_radius for d in MOVING],
            default=999.0,
        )
        nearest_static = min(
            [np.linalg.norm(s.center - self.x[:3]) - s.radius - CFG.vehicle_radius for s in STATIC],
            default=999.0,
        )
        threat = min(nearest_dyn, nearest_static)

        need_plan = (
            self.route is None
            or (threat < 3.8 and self.t - self.last_plan > 5.0)
        )
        if need_plan:
            reason = "initial" if self.route is None else "obstacle threat"
            self.plan(reason)

        refs = self._reference_horizon()
        if self.frame % CFG.control_every == 0:
            # Re-anchor the nominal trajectory to the measured state before each
            # finite-horizon solve, matching the receding-horizon measurement/reset
            # step used in the supplied 2020 control algorithm.
            self.nominal = self.x.copy()
            tau_nom, _ = self.controller.solve(self.nominal, refs, blocks)
            self.nominal_tau = tau_nom.copy()
            tau = tube_feedback(
                self.nominal_tau,
                self.x,
                self.nominal,
                np.asarray(CFG.tau_max, dtype=float),
            )
            tau, _ = self._safety_shield(tau)
        else:
            tau = self.commanded_tau.copy()
        return tau

    def step(self):
        if self.mission_complete:
            return

        self.current = sample_current(self.t)
        self.dist = sample_disturbance(self.t)
        self.frame += 1

        if self.t < 9.0:
            self.status = "DEPLOYING"
            tau = self._deployment_control()
        else:
            self.status = "MISSION"
            tau = self._mission_control()

        # Physical thruster slew-rate limit. The controller cannot instantaneously
        # realize a large change in force.
        # Keep separate traces of nominal predictive action, requested action after
        # tube-style/safety correction, and physically rate-limited applied action.
        tau_requested_log = np.asarray(tau, dtype=float).copy()
        tau_nominal_log = np.asarray(self.nominal_tau, dtype=float).copy()
        self.commanded_tau = tau_requested_log.copy()
        rate = np.asarray(CFG.tau_rate_max, dtype=float)
        tau_applied = self.last_applied_tau + np.clip(
            self.commanded_tau - self.last_applied_tau,
            -rate * CFG.dt,
            rate * CFG.dt,
        )
        tau_applied = np.clip(tau_applied, -np.asarray(CFG.tau_max), np.asarray(CFG.tau_max))

        # Record accelerations from the actual perturbed plant before integration.
        # dynamics() returns state derivatives in the documented state order:
        # Xdot,Ydot,Zdot,psidot,udot,vdot,wdot,rdot,phidot,thetadot,pdot,qdot.
        state_dot = dynamics(
            self.x,
            tau_applied,
            self.plant,
            disturbance=self.dist,
            current=self.current,
        )
        acc_u, acc_v, acc_w = (float(state_dot[4]), float(state_dot[5]), float(state_dot[6]))
        acc_p, acc_q, acc_r = (float(state_dot[10]), float(state_dot[11]), float(state_dot[7]))

        # Real plant: parameter mismatch + unknown disturbance + current.
        self.x = rk4(
            self.x,
            tau_applied,
            self.plant,
            CFG.dt,
            disturbance=self.dist,
            current=self.current,
        )
        # Nominal model used by the tube-style correction.
        self.nominal = rk4(self.nominal, self.nominal_tau, self.nom, CFG.dt)
        self.last_applied_tau = tau_applied.copy()
        self.t += CFG.dt

        # Metrics
        if self.route is not None and len(self.route) > 1:
            ref = self._route_target(lookahead=2.4)
            ref_next = self._route_target(lookahead=3.1)
            if np.linalg.norm(ref_next[:2] - ref[:2]) > 1e-6:
                ref_psi = math.atan2(
                    ref_next[1] - ref[1], ref_next[0] - ref[0])
            else:
                ref_psi = self.x[3]
        else:
            ref = np.array([
                self.x[0],self.x[1],CFG.deployment_depth])
            ref_psi = self.x[3]
        err_xyz = self.x[:3] - ref
        errX = float(err_xyz[0])
        errY = float(err_xyz[1])
        errZ = float(err_xyz[2])
        track_error = float(np.linalg.norm(err_xyz))
        self.max_track_error = max(self.max_track_error, track_error)

        clearances = []
        for s in STATIC:
            clearances.append(float(np.linalg.norm(self.x[:3] - s.center) - s.radius - CFG.vehicle_radius))
        for d in MOVING:
            clearances.append(float(np.linalg.norm(self.x[:3] - d.position(self.t)) - d.radius - CFG.vehicle_radius))
        mc = min(clearances) if clearances else 999.0
        self.min_clearance = min(self.min_clearance, mc)
        if mc < 0.0:
            self.collisions += 1

        # Goal completion check: close enough in 3-D after the deployment phase.
        goal_error = float(np.linalg.norm(self.x[:3] - self.goal))
        if self.t > 9.0 and goal_error <= 2.5:
            self.mission_complete = True
            self.status = "MISSION COMPLETE"

        errPhi = float(self.x[8])  # level attitude reference: roll=0
        errTheta = float(self.x[9])  # level attitude reference: pitch=0
        errPsi = float(wrap_angle(self.x[3] - ref_psi))
        self.rows.append([
            self.t,
            *self.x,
            acc_u,
            acc_v,
            acc_w,
            acc_p,
            acc_q,
            acc_r,
            *tau_nominal_log,
            *tau_requested_log,
            *tau_applied,
            *self.current,
            *self.dist,
            ref[0],
            ref[1],
            ref[2],
            ref_psi,
            errX,
            errY,
            errZ,
            track_error,
            errPhi,
            errTheta,
            errPsi,
            mc,
            goal_error,
            self.replans,
            int(self.status == "DEPLOYING"),
            ", ".join(self.detected_names),
        ])

    # ------------------------------------------------------------------
    # 3-D visualisation
    # ------------------------------------------------------------------
    def _make_scene(self):
        self.renderer = vtk.vtkRenderer()
        self.renderer.SetBackground(0.003, 0.014, 0.035)
        self.renderer.SetBackground2(0.0, 0.14, 0.23)
        self.renderer.GradientBackgroundOn()

        for pos, intensity, color in [
            ((-10, -14, 12), 1.55, (0.72, 0.88, 1.0)),
            ((22, 10, -1), 0.75, (0.38, 0.68, 0.92)),
            ((-30, 18, -12), 0.42, (0.36, 0.62, 0.78)),
        ]:
            l = vtk.vtkLight(); l.SetPosition(*pos); l.SetIntensity(intensity); l.SetColor(*color); self.renderer.AddLight(l)

        self.renderer.AddActor(seabed(BOUNDS, CFG.seed))
        self.renderer.AddActor(water_surface(BOUNDS))
        for a in light_beams(BOUNDS, 11, 31): self.renderer.AddActor(a)

        rng = np.random.default_rng(4)
        for c in reef_centers:
            for a in coral_cluster(c, 1.55, rng): self.renderer.AddActor(a)
        for c in [(-23,-2,-19.3),(-18,5,-19.1),(-14,-9,-19.0),(-8,11,-19.1),(1,5,-19.2),(4,-10,-19.0),(14,8,-19.0),(20,-7,-19.1),(25,1,-19.0)]:
            for a in sea_grass(c, rng.uniform(.8,1.35), rng): self.renderer.AddActor(a)
        for c in [(-20,12,-19),(-20,-10,-19),(1,-11,-19.1),(14,12,-19),(25,-11,-19)]:
            for a in rock_field(c, .9, 8, rng): self.renderer.AddActor(a)

        for a in wreck_ship([-2,-2.5,-18.6], 1.0): self.renderer.AddActor(a)
        for a in container([8.5,-1.5,-18.2], 1.0, 8): self.renderer.AddActor(a)
        for a in container([-5,9,-18.1], .9, -18): self.renderer.AddActor(a)
        for a in dynamite_cache([16.5,-.5,-18.6], 1.0): self.renderer.AddActor(a)
        for a in pipeline([1,12.2,-19], 22, -.12): self.renderer.AddActor(a)
        for a in pipeline([-18,3,-19.1], 17, .38): self.renderer.AddActor(a)
        for a in cable_bundle([13,-8,-18.8], 18, .10): self.renderer.AddActor(a)

        rng = np.random.default_rng(9)
        particles = [[rng.uniform(-29,29), rng.uniform(-17,17), rng.uniform(-20.5,-1.0)] for _ in range(1450)]
        self.renderer.AddActor(point_cloud(particles, (.72,.88,1.0,.10), 2))
        bubbles=[]
        for center in [(-13,-7),(-1,-4),(8,4),(19,-5),(24,9)]:
            for j in range(34):
                ang=j/34*2*math.pi; bubbles.append([center[0]+.58*math.cos(ang),center[1]+.58*math.sin(ang),-19.3+(j%17)*.76])
        self.renderer.AddActor(point_cloud(bubbles, (.77,.92,1.0,.17), 3))
        for i in range(18):
            pp=np.array([-25+(i*3.0)%50, -14+((i*7)%26), -3.5-((i*3)%11)])
            self.renderer.AddActor(fish_actor(pp, .7+.18*(i%3), (i%7)*.45))

        self.aurora_actor = line_actor(self.aurora_trace, (.55,.75,.95,.16), 2, dashed=True)
        self.renderer.AddActor(self.aurora_actor)
        self.launch_marker = sphere(CFG.launch_point, .55, (.12,.88,.98,.92))
        self.goal_marker = sphere(self.goal, .80, (.22,.98,.38,.92))
        self.renderer.AddActor(self.launch_marker); self.renderer.AddActor(self.goal_marker)

        self.auv = make_auv_actor(); self.renderer.AddActor(self.auv)
        self.moving_visuals={}; self.dynamic_labels={}
        for d in MOVING:
            a=make_submersible_actor(d.radius/1.18) if ('Submersible' in d.name or 'Drone' in d.name) else make_debris_actor(d.radius/.95)
            self.renderer.AddActor(a); self.moving_visuals[d.name]=a
            label=vtk.vtkBillboardTextActor3D(); label.SetInput(d.name); label.GetTextProperty().SetFontSize(12); label.GetTextProperty().SetColor(.98,.60,.45); label.SetScale(.010); self.renderer.AddActor(label); self.dynamic_labels[d.name]=label

        self.path_actor=None; self.actual_actor=None; self.dynamic_actors=[]; self.detected_actors=[]

        self.hud_title=text_actor("AUTONOMOUS UNDERWATER VEHICLE  |  OBSTACLE AVOIDANCE MISSION",(18,855),20,(.94,.98,1),(.02,.05,.08),.88,True,True)
        self.hud_mode=text_actor("AUTO  |  ROBUST TUBE-MPC  |  6-DOF UNDERWATER MODEL",(1020,855),13,(.42,1,.65),(.02,.05,.08),.88,True,True)
        self.hud_mission=text_actor("",(18,665),13)
        self.hud_telemetry=text_actor("",(1190,650),13)
        self.hud_controller=text_actor("",(1190,485),13)
        self.hud_obstacles=text_actor("",(1190,300),13)
        self.hud_sensors=text_actor("",(18,48),12,(.74,.92,1),(.02,.05,.08),.78,True)
        self.hud_help=text_actor("SPACE Pause   R Restart   1 Overview   2 Follow   3 Free   4 Top   S Screenshot   ESC Exit",(18,14),11,(.65,.78,.86),(.02,.04,.06),.70,True)
        for ta in [self.hud_title,self.hud_mode,self.hud_mission,self.hud_telemetry,self.hud_controller,self.hud_obstacles,self.hud_sensors,self.hud_help]: self.renderer.AddViewProp(ta)

        self.window=vtk.vtkRenderWindow(); self.window.AddRenderer(self.renderer); self.window.SetSize(1480,900); self.window.SetWindowName("AUV Autonomous Underwater Mission | Robust NMPC")
        self.interactor=vtk.vtkRenderWindowInteractor(); self.interactor.SetRenderWindow(self.window); self.interactor.SetInteractorStyle(vtk.vtkInteractorStyleTrackballCamera()); self.interactor.AddObserver("KeyPressEvent",self.on_key)
        self.window.Render(); self._update_scene()

    def on_key(self,obj,evt):
        key=self.interactor.GetKeySym().lower()
        if key=='space': self.paused=not self.paused
        elif key=='r': self.interactor.TerminateApp();
        elif key=='s': self.save_screenshot()
        elif key=='1': self.set_mission_view()
        elif key=='2': self.set_follow_view()
        elif key=='3': self.set_free_view()
        elif key=='4':
            self.camera_mode = 'top'
            cam=self.renderer.GetActiveCamera(); cam.SetPosition(0,-.5,55); cam.SetFocalPoint(0,0,-12); cam.SetViewUp(0,1,0); cam.SetViewAngle(50); self.renderer.ResetCameraClippingRange()
        elif key=='escape': self.interactor.TerminateApp()

    def set_mission_view(self):
        self.camera_mode = 'overview'
        cam=self.renderer.GetActiveCamera(); cam.SetPosition(39,-48,18); cam.SetFocalPoint(-1,-1,-12); cam.SetViewUp(0,0,1); cam.SetViewAngle(48); self.renderer.ResetCameraClippingRange()

    def set_follow_view(self):
        self.camera_mode = 'follow'
        cam=self.renderer.GetActiveCamera(); p=self.x[:3]; f=np.array([math.cos(self.x[3]),math.sin(self.x[3]),0.0]); cam.SetPosition(*(p-13*f+np.array([0,0,5.5]))); cam.SetFocalPoint(*(p+6.5*f+np.array([0,0,-1]))); cam.SetViewUp(0,0,1); cam.SetViewAngle(46); self.renderer.ResetCameraClippingRange()

    def set_free_view(self):
        self.camera_mode = 'free'

        cam = self.renderer.GetActiveCamera()

        cam.SetPosition(32, -38, 8)
        cam.SetFocalPoint(0, 0, -12)
        cam.SetViewUp(0, 0, 1)
        cam.SetViewAngle(55)

        cam.ParallelProjectionOff()
        self.renderer.ResetCameraClippingRange()
        self.window.Render()

    def save_screenshot(self):
        """Save a screenshot only when VTK has a valid, non-empty render buffer."""
        if self.headless:
            return
        try:
            # A minimized/closing render window can report a zero-sized buffer.
            size = self.window.GetSize()
            if not size or len(size) < 2 or size[0] <= 0 or size[1] <= 0:
                print("Screenshot skipped: render window has zero width or height.")
                return

            self.window.Render()
            filt = vtk.vtkWindowToImageFilter()
            filt.SetInput(self.window)
            # On Windows, capture the completed front buffer to avoid reading
            # an empty/stale back buffer after the final render.
            filt.ReadFrontBufferOn()
            filt.SetInputBufferTypeToRGB()
            filt.Update()
            image_data = filt.GetOutput()
            dims = image_data.GetDimensions() if image_data is not None else (0, 0, 0)
            if len(dims) < 2 or dims[0] <= 0 or dims[1] <= 0:
                print(f"Screenshot skipped: VTK returned an empty image ({dims}).")
                return

            out = vtk.vtkPNGWriter()
            out.SetFileName(str(RESULTS / 'final_view.png'))
            out.SetInputData(image_data)
            out.Write()
            print(f"Screenshot saved: {RESULTS / 'final_view.png'} ({dims[0]}x{dims[1]}).")
        except Exception as exc:
            # Screenshot export is optional and should not break the simulation.
            print(f"Screenshot skipped because VTK capture failed: {exc}")

    def _sensor_scan_geometry(self):
        p=self.x[:3]; yaw=self.x[3]; out=[]
        for a in np.linspace(-.95,.95,9):
            ang=yaw+a; end=p+np.array([math.cos(ang),math.sin(ang),0])*CFG.sensor_range; out.append(line_actor(np.vstack([p,end]),(.20,.84,.98,.12),1))
        end=p+np.array([math.cos(yaw),math.sin(yaw),0])*CFG.sensor_range; out.append(line_actor(np.vstack([p,end]),(.25,.92,1,.38),2)); return out

    def _update_scene(self):
        if self.headless: return
        for a in self.dynamic_actors+self.detected_actors: self.renderer.RemoveActor(a)
        self.dynamic_actors.clear(); self.detected_actors.clear()
        if self.path_actor is not None: self.renderer.RemoveActor(self.path_actor)
        if self.actual_actor is not None: self.renderer.RemoveActor(self.actual_actor)
        if self.route is not None:
            self.path_actor=line_actor(self.route,(.18,1,.48,.96),5); self.renderer.AddActor(self.path_actor)
        if self.rows:
            arr=np.asarray(self.rows,dtype=object); xyz=np.asarray(arr[:,1:4],float); self.actual_actor=line_actor(xyz,(.24,.55,1,.98),4); self.renderer.AddActor(self.actual_actor)

        for d in MOVING:
            p=d.position(self.t); self.moving_visuals[d.name].SetPosition(*p); self.dynamic_labels[d.name].SetPosition(*(p+np.array([0,0,d.radius+.45])))
            trail=np.asarray([d.position(tt) for tt in np.linspace(max(0,self.t-9),self.t+.8,50)]); tr=line_actor(trail,(.95,.34,.18,.42),2,dashed=True); self.renderer.AddActor(tr); self.dynamic_actors.append(tr)
            pred=np.asarray([d.position(tt) for tt in np.linspace(self.t,self.t+6,28)]); pr=line_actor(pred,(1,.52,.32,.68),2,dashed=True); self.renderer.AddActor(pr); self.dynamic_actors.append(pr)
            if d.name in self.detected_names:
                ring=sphere(p,d.radius+.72,(.98,.12,.08,.14)); self.renderer.AddActor(ring); self.detected_actors.append(ring)
                future=d.position(self.t+3); predm=sphere(future,.34,(1,.45,.16,.62)); self.renderer.AddActor(predm); self.detected_actors.append(predm)

        cv=self.current
        if np.linalg.norm(cv)>1e-5:
            end=self.x[:3]+np.asarray(cv)*22; ar=line_actor(np.vstack([self.x[:3],end]),(.18,.80,.96,.62),4); self.renderer.AddActor(ar); self.dynamic_actors.append(ar); hd=sphere(end,.18,(.18,.80,.96,.62),16); self.renderer.AddActor(hd); self.dynamic_actors.append(hd)

        sp=vtk.vtkSphereSource(); sp.SetCenter(*self.x[:3]); sp.SetRadius(CFG.sensor_range); sp.SetThetaResolution(32); sp.SetPhiResolution(20); sp.Update(); sa=actor(sp.GetOutput(),(.08,.46,.86,.038),.038,specular=0,power=1); self.renderer.AddActor(sa); self.detected_actors.append(sa)
        for ray in self._sensor_scan_geometry(): self.renderer.AddActor(ray); self.detected_actors.append(ray)
        yaw=self.x[3]; nose=self.x[:3]+np.array([math.cos(yaw),math.sin(yaw),0])*2.4; fend=nose+np.array([math.cos(yaw),math.sin(yaw),-.04])*8.5; cb=line_actor(np.vstack([nose,fend]),(.76,.94,.98,.38),5); self.renderer.AddActor(cb); self.dynamic_actors.append(cb)

        if self.camera_mode == 'follow':
            p=self.x[:3]; f=np.array([math.cos(self.x[3]),math.sin(self.x[3]),0.0]); cam=self.renderer.GetActiveCamera(); cam.SetPosition(*(p-13*f+np.array([0,0,5.5]))); cam.SetFocalPoint(*(p+6.5*f+np.array([0,0,-1]))); cam.SetViewUp(0,0,1)
            self.renderer.ResetCameraClippingRange()
        elif self.camera_mode == 'free':
            # Do not automatically change the camera.
            # Mouse controls the camera in this mode.
            pass

        self.auv.SetPosition(*self.x[:3]); self.auv.SetOrientation(math.degrees(self.x[8]), math.degrees(self.x[9]), math.degrees(self.x[3]))
        goal_error=float(np.linalg.norm(self.x[:3]-self.goal)); detections=', '.join(self.detected_names) if self.detected_names else 'none'
        nearest_dyn=min([np.linalg.norm(d.position(self.t)-self.x[:3])-d.radius-CFG.vehicle_radius for d in MOVING],default=999.)
        nearest_static=min([np.linalg.norm(s.center-self.x[:3])-s.radius-CFG.vehicle_radius for s in STATIC],default=999.)
        predicted=self._predicted_collision(); ttc='--'; risk='LOW'
        if predicted is not None:
            pc,_,_,pt=predicted; ttc=f'{max(0,pt-self.t):.1f} s'; risk='HIGH' if pc<1.8 else ('MED' if pc<3.5 else 'LOW')
        self.hud_mission.SetInput('MISSION STATUS\n'+f'Mode            {self.status}\nMission time    {self.t:6.1f} s\nReplans         {self.replans:4d}\nGoal error      {goal_error:6.2f} m\nGoal            ({self.goal[0]:.1f}, {self.goal[1]:.1f}, {self.goal[2]:.1f})\nRoute           {"ACTIVE" if self.route is not None else "SEARCHING"}')
        self.hud_telemetry.SetInput('AUV TELEMETRY\n'+f'Position        ({self.x[0]:6.2f}, {self.x[1]:6.2f}, {self.x[2]:6.2f}) m\nDepth           {-self.x[2]:6.2f} m\nSurge u         {self.x[4]:+5.2f} m/s\nSway v          {self.x[5]:+5.2f} m/s\nHeave w         {self.x[6]:+5.2f} m/s\nYaw             {math.degrees(self.x[3]):+5.1f} deg\nCurrent         ({self.current[0]:+.2f}, {self.current[1]:+.2f}) m/s')
        self.hud_controller.SetInput('CONTROLLER OUTPUT\nRobust finite-horizon NMPC + tube correction\n'+f'tauX            {self.last_applied_tau[0]:+6.2f} N\ntauZ            {self.last_applied_tau[1]:+6.2f} N\ntauN            {self.last_applied_tau[2]:+6.2f} Nm\nTracked error   {self.max_track_error:6.2f} m\nMin clearance   {self.min_clearance:6.2f} m\nForce limits    {CFG.tau_max[0]:.0f}/{CFG.tau_max[1]:.0f}/{CFG.tau_max[2]:.0f}\nSlew limits     {CFG.tau_rate_max[0]:.0f}/{CFG.tau_rate_max[1]:.0f}/{CFG.tau_rate_max[2]:.0f}')
        self.hud_obstacles.SetInput('OBSTACLE DETECTION\n'+f'Detected         {len(self.detected_names):2d}\nMoving objects   {sum("Moving" in n or "Submersible" in n for n in self.detected_names):2d}\nStatic clearance {nearest_static:6.2f} m\nDynamic clearance{nearest_dyn:6.2f} m\nPredicted TTC    {ttc}\nCollision risk   {risk}\nReplanning       {"ACTIVE" if self.route is not None else "SEARCHING"}\nTargets          {detections}')
        self.hud_sensors.SetInput(f'SENSORS | SONAR {CFG.sensor_range:.0f} m ACTIVE | CAMERA FRUSTUM ACTIVE | AURORA {"ON" if self.aurora_used else "DEMO TRACK"} | CURRENT VECTOR ACTIVE | PATHS: green planned / blue actual / orange prediction')
        self.window.Render()

    # ------------------------------------------------------------------
    # Execution / logs
    # ------------------------------------------------------------------
    def run(self):
        self.set_mission_view()
        self.interactor.Initialize()
        self.window.Render()
        last_render = time.perf_counter()

        while self.interactor.GetDone() == 0 and self.t < CFG.total_time and not self.mission_complete:
            if not self.paused:
                self.step()
                self._update_scene()
            else:
                time.sleep(0.05)
            self.interactor.ProcessEvents()
            if time.perf_counter() - last_render < 0.03:
                time.sleep(0.008)
            last_render = time.perf_counter()

        self.save_screenshot()
        self.write_logs()
        self._update_scene()
        while self.interactor.GetDone() == 0:
            self.interactor.ProcessEvents()
            time.sleep(0.03)

    def write_logs(self):
        fields = [
            "time", "X", "Y", "Z", "psi", "u", "v", "w", "r", "phi", "theta", "p", "q",
            "acc_u", "acc_v", "acc_w", "acc_p", "acc_q", "acc_r",
            "tauNomX", "tauNomZ", "tauNomN", "tauReqX", "tauReqZ", "tauReqN",
            "tauX", "tauZ", "tauN", "curX", "curY", "curZ", "dX", "dY", "dZ", "refX", "refY", "refZ", "refPsi", "errX", "errY", "errZ", "track_error", "errPhi", "errTheta", "errPsi", "min_clearance", "goal_error", "replans", "deployment", "detected"
        ]
        with open(RESULTS / "mission_log.csv", "w", newline="", encoding="utf-8") as f:
            wr = csv.writer(f)
            wr.writerow(fields)
            wr.writerows(self.rows)

        final_goal_error = float(np.linalg.norm(self.x[:3] - self.goal))
        summary = (
            "AUV Autonomous Underwater Moving-Obstacle Mission\n"
            "==============================================\n"
            f"AURORA source: {self.aurora_msg}\n"
            f"AURORA used for run: {self.aurora_used}\n"
            f"Final status: {self.status}\n"
            f"Final time: {self.t:.2f} s\n"
            f"Final position (X,Y,Z): {self.x[0]:.3f}, {self.x[1]:.3f}, {self.x[2]:.3f}\n"
            f"Goal: {self.goal.tolist()}\n"
            f"Final goal error: {final_goal_error:.3f} m\n"
            f"Replans: {self.replans}\n"
            f"Minimum clearance margin: {self.min_clearance:.3f} m\n"
            f"Maximum reference tracking error: {self.max_track_error:.3f} m\n"
            f"Collision samples: {self.collisions}\n"
            f"Moving obstacles: {', '.join(d.name for d in MOVING)}\n"
            f"Robustness: plant parameter mismatch + bounded current + unknown force disturbance\n"
            f"Controller: fast finite-horizon nonlinear predictive controller + tube-style feedback\n"
        )
        (RESULTS / "mission_summary.txt").write_text(summary, encoding="utf-8")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="AUV moving-obstacle underwater mission simulation")
    ap.add_argument("--headless", action="store_true", help="Run without VTK GUI and write result logs")
    ap.add_argument("--seconds", type=float, default=None, help="Override simulation duration")
    args = ap.parse_args()

    if args.seconds is not None:
        CFG.total_time = float(args.seconds)

    sim = Simulation(headless=args.headless)
    if args.headless:
        while sim.t < CFG.total_time and not sim.mission_complete:
            sim.step()
        sim.write_logs()
        print(sim.aurora_msg)
        print(f"status={sim.status}")
        print(f"final={sim.x[:3]}")
        print(f"goal={sim.goal}")
        print(f"goal_error={np.linalg.norm(sim.x[:3]-sim.goal):.3f}")
        print(f"replans={sim.replans}")
        print(f"min_clearance={sim.min_clearance:.3f}")
        print(f"collisions={sim.collisions}")
    else:
        sim.run()
