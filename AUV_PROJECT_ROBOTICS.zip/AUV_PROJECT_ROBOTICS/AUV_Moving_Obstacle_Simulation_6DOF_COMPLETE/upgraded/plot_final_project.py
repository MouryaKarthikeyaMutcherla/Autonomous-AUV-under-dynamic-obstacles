"""Generate combined 6-DOF and controller-specific figures from this project's run log."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results'
LOG = OUT / 'mission_log.csv'
if not LOG.exists():
    raise FileNotFoundError(f'{LOG} not found. Run `py main.py --headless` first.')
df = pd.read_csv(LOG)
required = ['time','X','Y','Z','phi','theta','psi','u','v','w','p','q','r',
            'acc_u','acc_v','acc_w','acc_p','acc_q','acc_r','tauX','tauZ','tauN',
            'refX','refY','refZ','errX','errY','errZ','track_error','min_clearance']
missing = [c for c in required if c not in df.columns]
if missing:
    raise ValueError('The run log is missing required signals: ' + ', '.join(missing) + '. Run the updated main.py again.')
t = df['time'].to_numpy()

def finish(fig, filename):
    fig.tight_layout()
    fig.savefig(OUT / filename, dpi=220, bbox_inches='tight')
    plt.close(fig)
    print(f'created {OUT / filename}')

# One figure with all six-DOF state families, each in its own panel.
fig, axs = plt.subplots(3, 2, figsize=(17, 12), sharex=True)
items = [
    (['X','Y','Z'], ['X','Y','Z'], 'Position (m)', 'Position'),
    (['phi','theta','psi'], ['Roll φ','Pitch θ','Yaw ψ'], 'Angle (deg)', 'Orientation'),
    (['u','v','w'], ['Surge u','Sway v','Heave w'], 'Velocity (m/s)', 'Body linear velocity'),
    (['p','q','r'], ['Roll rate p','Pitch rate q','Yaw rate r'], 'Rate (rad/s)', 'Body angular velocity'),
    (['acc_u','acc_v','acc_w'], ['Longitudinal','Lateral','Vertical'], 'Acceleration (m/s²)', 'Body linear acceleration'),
    (['acc_p','acc_q','acc_r'], ['Roll','Pitch','Yaw'], 'Acceleration (rad/s²)', 'Body angular acceleration'),
]
for ax, (cols, labels, ylabel, title) in zip(axs.flat, items):
    for c, label in zip(cols, labels):
        y = np.rad2deg(df[c].to_numpy()) if c in ('phi','theta','psi') else df[c].to_numpy()
        ax.plot(t, y, label=label, linewidth=1.05)
    ax.set_title(title, fontsize=12)
    ax.set_ylabel(ylabel)
    ax.grid(True, alpha=.28)
    ax.legend(fontsize=8, ncol=3, loc='best')
for ax in axs[-1,:]: ax.set_xlabel('Time (s)')
fig.suptitle('AUV Six-DOF Dynamics — One-Run State Dashboard', fontsize=16)
finish(fig, 'sixdof_all_in_one.png')

# Controller output: nominal NMPC action, post-correction requested action, and applied action.
if all(c in df.columns for c in ['tauNomX','tauNomZ','tauNomN','tauReqX','tauReqZ','tauReqN']):
    fig, axs = plt.subplots(3, 1, figsize=(14, 10), sharex=True)
    pairs = [('X','Surge force (N)'),('Z','Heave force (N)'),('N','Yaw moment (N·m)')]
    for ax, (suffix, ylabel) in zip(axs, pairs):
        ax.plot(t, df['tauNom'+suffix], label='Nominal NMPC output', linewidth=1.0)
        ax.plot(t, df['tauReq'+suffix], label='After tube-style correction / safety shield', linewidth=1.0)
        ax.plot(t, df['tau'+suffix], label='Applied after actuator slew/rate limits', linewidth=1.0, alpha=.9)
        ax.set_ylabel(ylabel); ax.grid(True, alpha=.28); ax.legend(fontsize=8, ncol=3)
    axs[-1].set_xlabel('Time (s)')
    fig.suptitle('Implemented Controller Outputs: NMPC + Tube-Style Correction', fontsize=15)
    finish(fig, 'controller_nmpc_vs_corrected_applied.png')

    # Difference is labelled net correction because safety-shield actions can be included.
    fig, axs = plt.subplots(3, 1, figsize=(14, 9), sharex=True)
    for ax, (suffix, ylabel) in zip(axs, pairs):
        corr = df['tauReq'+suffix].to_numpy() - df['tauNom'+suffix].to_numpy()
        ax.plot(t, corr, label='Net correction (requested − nominal)', linewidth=1.0)
        ax.axhline(0, color='black', linewidth=.7)
        ax.set_ylabel(ylabel); ax.grid(True, alpha=.28); ax.legend(fontsize=8)
    axs[-1].set_xlabel('Time (s)')
    fig.suptitle('Tube-Style Feedback / Safety-Shield Net Control Correction', fontsize=15)
    finish(fig, 'controller_net_correction.png')
else:
    raise ValueError('Updated controller command traces were not logged; rerun updated main.py.')

# Controller performance figure with directly logged tracking error and clearance.
fig, axs = plt.subplots(2, 1, figsize=(14, 7), sharex=True)
axs[0].plot(t, df['track_error'], label='3D reference tracking error')
axs[0].set_ylabel('Error (m)'); axs[0].grid(True, alpha=.28); axs[0].legend()
axs[1].plot(t, df['min_clearance'], label='Minimum obstacle clearance')
axs[1].axhline(0, linestyle='--', label='Collision boundary')
axs[1].axhline(1.5, linestyle=':', label='1.5 m reference threshold')
axs[1].set_ylabel('Clearance (m)'); axs[1].set_xlabel('Time (s)'); axs[1].grid(True, alpha=.28); axs[1].legend()
fig.suptitle('Controller Mission Performance', fontsize=15)
finish(fig, 'controller_tracking_and_clearance.png')

# Numeric validation and metrics summary.
finite_cols = required + [c for c in ['tauNomX','tauNomZ','tauNomN','tauReqX','tauReqZ','tauReqN'] if c in df.columns]
if not np.isfinite(df[finite_cols].to_numpy(dtype=float)).all():
    raise ValueError('NaN/Inf found in required signals.')
pos_err = np.sqrt(df['errX']**2 + df['errY']**2 + df['errZ']**2)
summary = [
    'Final project plot validation',
    f'Samples: {len(df)}',
    f'Duration: {float(t[-1]):.3f} s',
    f'Position-error RMS: {float(np.sqrt(np.mean(pos_err**2))):.4f} m',
    f'Position-error maximum: {float(pos_err.max()):.4f} m',
    f'Minimum obstacle clearance: {float(df.min_clearance.min()):.4f} m',
    f'Collision samples (clearance < 0): {int((df.min_clearance < 0).sum())}',
    'Controller structure: RobustNMPC nominal predictive action + tube-style feedback correction + safety shield + applied actuator slew/rate limiting.',
    'Important: this is not a separately implemented standalone Tube MPC controller; the correction is a simplified tube-style feedback term.',
]
(OUT / 'final_plot_validation.txt').write_text('\n'.join(summary)+'\n', encoding='utf-8')
print('\n'.join(summary))
