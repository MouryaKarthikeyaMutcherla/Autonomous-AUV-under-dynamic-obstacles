@echo off
setlocal
cd /d "%~dp0"
py -c "import numpy, scipy, pandas, vtk, matplotlib" >nul 2>&1
if errorlevel 1 (
    echo Installing simulation dependencies...
    py -m pip install -r requirements.txt
    if errorlevel 1 (pause & exit /b 1)
)
echo Starting selectable-controller AUV mission simulator...
py main.py %*
if errorlevel 1 (echo Simulation failed. Check the traceback above. & pause & exit /b 1)
echo Generating result figures...
py plot_final_project.py
if errorlevel 1 echo Plot generation failed; check results\mission_log.csv.
echo Results are in results\.
pause
