Controller comparison runs were executed with the same scenario settings and initial seed.
Results are specific to this configuration and simulation model; they are not real-vehicle validation.
Each controller log is saved separately alongside controller_comparison.csv.
