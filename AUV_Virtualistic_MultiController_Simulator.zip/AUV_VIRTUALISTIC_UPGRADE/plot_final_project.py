"""Generate model-consistent state, control, force/moment, and tracking plots."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
LOG = OUT / "mission_log.csv"
if not LOG.exists():
    raise FileNotFoundError("Run main.py first; results/mission_log.csv was not found.")
df = pd.read_csv(LOG)
required = ["time", "X", "Y", "Z", "psi", "u", "v", "w", "r", "acc_u", "acc_v", "acc_w", "acc_r",
            "tau_nom_X", "tau_nom_Z", "tau_nom_N", "tau_cmd_X", "tau_cmd_Z", "tau_cmd_N",
            "tauX", "tauZ", "tauN", "track_error", "min_clearance", "goal_error"]
missing = [c for c in required if c not in df.columns]
if missing:
    raise ValueError("Mission log is missing columns: " + ", ".join(missing))
mode = str(df["controller_mode"].iloc[-1]) if "controller_mode" in df.columns else "unknown"
scenario = str(df["scenario"].iloc[-1]) if "scenario" in df.columns else "unknown"

def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / name, dpi=180, bbox_inches="tight")
    plt.close(fig)

def axis(ax, x, ys, title, ylabel):
    for col, label in ys:
        ax.plot(df[x], df[col], label=label, lw=1.15)
    ax.set_title(title)
    ax.set_xlabel("Time (s)")
    ax.set_ylabel(ylabel)
    ax.grid(True, alpha=.28)
    ax.legend(fontsize=8)

# Model-accurate state dashboard: source dynamics has 8 states, not a full 12-state 6-DOF model.
fig, axs = plt.subplots(3, 2, figsize=(15, 10))
axis(axs[0,0], "time", [("X","X position"),("Y","Y position"),("Z","Z position")], "Position (world frame)", "Position (m)")
axis(axs[0,1], "time", [("psi","Yaw ψ")], "Orientation available in model", "Yaw (rad)")
axis(axs[1,0], "time", [("u","Surge velocity u"),("v","Sway velocity v"),("w","Heave velocity w")], "Body linear velocities", "Velocity (m/s)")
axis(axs[1,1], "time", [("r","Yaw rate r")], "Angular velocity available in model", "Angular rate (rad/s)")
axis(axs[2,0], "time", [("acc_u","Surge acceleration"),("acc_v","Sway acceleration"),("acc_w","Heave acceleration")], "Body linear accelerations", "Acceleration (m/s²)")
axis(axs[2,1], "time", [("acc_r","Yaw angular acceleration")], "Angular acceleration available in model", "Angular acceleration (rad/s²)")
fig.suptitle(f"AUV Simulation State Dashboard | Controller: {mode} | Scenario: {scenario}", fontsize=15)
save(fig, "sixdof_all_in_one.png")

# Generic command stages so labels remain correct when selecting non-NMPC controllers.
fig, axs = plt.subplots(3, 1, figsize=(12, 9), sharex=True)
for ax, nom, cmd, app, title, unit in zip(
    axs,
    ["tau_nom_X","tau_nom_Z","tau_nom_N"],
    ["tau_cmd_X","tau_cmd_Z","tau_cmd_N"],
    ["tauX","tauZ","tauN"],
    ["Longitudinal force input", "Vertical force input", "Yaw moment input"],
    ["N", "N", "N·m"],
):
    axis(ax, "time", [(nom,"Base controller output"),(cmd,"After feedback / safety stage"),(app,"Applied after actuator limits")], title, unit)
fig.suptitle(f"Controller Command Pipeline | {mode} | {scenario}")
save(fig, "controller_nmpc_vs_corrected_applied.png")

fig, axs = plt.subplots(3, 1, figsize=(12, 8), sharex=True)
for ax, nom, cmd, title, unit in zip(
    axs,
    ["tau_nom_X","tau_nom_Z","tau_nom_N"],
    ["tau_cmd_X","tau_cmd_Z","tau_cmd_N"],
    ["Requested − base longitudinal force", "Requested − base vertical force", "Requested − base yaw moment"],
    ["N", "N", "N·m"],
):
    delta = "delta_" + cmd
    df[delta] = df[cmd] - df[nom]
    axis(ax, "time", [(delta, "Net change after processing")], title, unit)
fig.suptitle("Net Difference from Base Controller Command")
save(fig, "controller_net_correction.png")

fig, axs = plt.subplots(3, 1, figsize=(11.5, 8.5), sharex=True)
for ax, col, title, ylabel in [
    (axs[0], "tauX", "Longitudinal (surge) control force τX", "Force (N)"),
    (axs[1], "tauZ", "Vertical (heave) control force τZ", "Force (N)"),
    (axs[2], "tauN", "Yaw control moment τN", "Moment (N·m)"),
]:
    ax.plot(df["time"], df[col], label="Applied input", lw=1.3)
    ax.set_title(title); ax.set_ylabel(ylabel); ax.set_xlabel("Time (s)")
    ax.grid(True, alpha=.28); ax.legend(fontsize=8)
fig.suptitle(f"AUV Applied Control Forces and Moment | {mode} | {scenario}")
save(fig, "controller_force_and_moment.png")

fig, axs = plt.subplots(2, 1, figsize=(12, 7), sharex=True)
axis(axs[0], "time", [("track_error","Reference tracking error"),("goal_error","Distance to goal")], "Tracking and goal error", "Error (m)")
axis(axs[1], "time", [("min_clearance","Reported minimum obstacle clearance")], "Obstacle clearance", "Clearance (m)")
axs[1].axhline(0, color="red", ls="--", lw=1, label="Collision boundary")
axs[1].legend(fontsize=8)
fig.suptitle("Mission Tracking and Clearance Metrics")
save(fig, "controller_tracking_and_clearance.png")

# If a comparison has been run, plot per-controller metrics without mixing the scales.
comparison_csv = OUT / "controller_comparison" / "controller_comparison.csv"
if comparison_csv.exists():
    comp = pd.read_csv(comparison_csv)
    labels = comp["controller"].astype(str).tolist()
    fig, axs = plt.subplots(2, 2, figsize=(12, 8))
    panels = [
        ("goal_error_m", "Final goal error", "Distance (m)"),
        ("track_error_rms_m", "RMS tracking error", "RMS (m)"),
        ("min_clearance_m", "Minimum reported clearance", "Clearance (m)"),
        ("replans", "Route replans", "Count"),
    ]
    for ax, (col, title, unit) in zip(axs.ravel(), panels):
        ax.bar(labels, comp[col])
        ax.set_title(title); ax.set_ylabel(unit); ax.grid(True, axis="y", alpha=.25)
        ax.tick_params(axis="x", rotation=18)
    fig.suptitle("Controller Comparison | Same configured scenario")
    save(fig, "controller_comparison.png")

summary = (OUT / "mission_summary.txt").read_text(errors="replace") if (OUT / "mission_summary.txt").exists() else ""
(OUT / "final_plot_validation.txt").write_text(
    "AUV SIMULATOR GRAPH VALIDATION\n==============================\n" + summary +
    "\nGraph note: the model state is [X,Y,Z,psi,u,v,w,r] (eight states), not a full six-DOF/12-state model. "
    "Therefore roll, pitch, p/q and their accelerations are not fabricated. The force/moment figure plots the applied "
    "generalized inputs tauX (longitudinal force, N), tauZ (vertical force, N) and tauN (yaw moment, N m).\n",
    encoding="utf-8",
)
print("Generated model-consistent graphs in results/:")
for name in ["sixdof_all_in_one.png", "controller_nmpc_vs_corrected_applied.png", "controller_net_correction.png",
             "controller_force_and_moment.png", "controller_tracking_and_clearance.png"]:
    print(f"  {name}: {(OUT / name).stat().st_size:,} bytes")
if comparison_csv.exists(): print(f"  controller_comparison.png: {(OUT / 'controller_comparison.png').stat().st_size:,} bytes")
