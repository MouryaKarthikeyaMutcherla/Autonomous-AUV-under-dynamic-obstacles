"""Generate only the four requested figures from the latest mission log."""
from runpy import run_path
from pathlib import Path
run_path(str(Path(__file__).resolve().parent / 'plot_final_project.py'), run_name='__main__')
