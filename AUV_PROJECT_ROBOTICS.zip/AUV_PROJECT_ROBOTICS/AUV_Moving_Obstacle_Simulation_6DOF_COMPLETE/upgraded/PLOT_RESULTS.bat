@echo off
setlocal
cd /d "%~dp0"
py -c "import pandas, matplotlib" >nul 2>&1
if errorlevel 1 (
    echo Installing plotting dependencies...
    py -m pip install -r requirements.txt
    if errorlevel 1 (
        echo Dependency installation failed.
        pause
        exit /b 1
    )
)
py plot_final_project.py
if errorlevel 1 echo Plot generation failed. Check results\mission_log.csv and the error above.
echo.
echo Only the requested four figures are generated in the results folder.
pause
