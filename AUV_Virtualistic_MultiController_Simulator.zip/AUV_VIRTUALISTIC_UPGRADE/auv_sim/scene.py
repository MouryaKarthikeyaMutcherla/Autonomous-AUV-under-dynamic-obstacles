from __future__ import annotations

import math
import numpy as np
import vtk

def _beautify(a, ambient=0.16, diffuse=0.84, specular=0.45, power=55):
    p = a.GetProperty()
    p.SetAmbient(ambient)
    p.SetDiffuse(diffuse)
    p.SetSpecular(specular)
    p.SetSpecularPower(power)
    p.SetInterpolationToPhong()
    return a


def actor(poly, rgba=(0.7,0.7,0.7,1.0), opacity=None, specular=0.25, power=35):
    mapper=vtk.vtkPolyDataMapper(); mapper.SetInputData(poly)
    a=vtk.vtkActor(); a.SetMapper(mapper); a.GetProperty().SetColor(*rgba[:3]); a.GetProperty().SetOpacity(opacity if opacity is not None else rgba[3])
    _beautify(a,.16,.84,specular,power)
    return a


def sphere(center, radius, rgba, res=24):
    src = vtk.vtkSphereSource(); src.SetCenter(*center); src.SetRadius(radius); src.SetThetaResolution(max(12,res)); src.SetPhiResolution(max(8,res//2)); src.Update()
    return actor(src.GetOutput(), rgba)


def cube(center, scale, rgba, rotation=None):
    src = vtk.vtkCubeSource()
    src.SetCenter(*center)
    src.SetXLength(scale[0])
    src.SetYLength(scale[1])
    src.SetZLength(scale[2])
    src.Update()
    a = actor(src.GetOutput(), rgba)
    if rotation:
        a.RotateX(rotation[0])
        a.RotateY(rotation[1])
        a.RotateZ(rotation[2])
    return a


def cylinder_between(p1, p2, radius, rgba, res=16):
    p1 = np.asarray(p1, float)
    p2 = np.asarray(p2, float)
    v = p2 - p1
    L = float(np.linalg.norm(v))
    if L < 1e-8:
        return sphere(p1, radius, rgba)
    mid = (p1 + p2) / 2

    src = vtk.vtkCylinderSource()
    src.SetRadius(radius)
    src.SetHeight(L)
    src.SetResolution(res)
    src.Update()
    a = actor(src.GetOutput(), rgba)
    a.SetPosition(*mid)

    z = np.array([0, 0, 1.0])
    vhat = v / L
    axis = np.cross(z, vhat)
    dot = np.clip(np.dot(z, vhat), -1, 1)
    angle = np.degrees(np.arccos(dot))
    if np.linalg.norm(axis) > 1e-8:
        axis /= np.linalg.norm(axis)
        a.RotateWXYZ(angle, *axis)
    elif dot < 0:
        a.RotateX(180)
    return a


def line_actor(points, rgba=(0.2,1,0.4,1), width=3, dashed=False):
    pts=np.asarray(points,float)
    if len(pts)<2: pts=np.vstack([pts,pts])
    vp=vtk.vtkPoints(); lines=vtk.vtkCellArray()
    for q in pts: vp.InsertNextPoint(*q)
    for i in range(len(pts)-1):
        ln=vtk.vtkLine(); ln.GetPointIds().SetId(0,i); ln.GetPointIds().SetId(1,i+1); lines.InsertNextCell(ln)
    pd=vtk.vtkPolyData(); pd.SetPoints(vp); pd.SetLines(lines)
    m=vtk.vtkPolyDataMapper();m.SetInputData(pd);a=vtk.vtkActor();a.SetMapper(m);a.GetProperty().SetColor(*rgba[:3]);a.GetProperty().SetOpacity(rgba[3]);a.GetProperty().SetLineWidth(width)
    if dashed:
        try:
            a.GetProperty().SetLineStipplePattern(0xF0F0);a.GetProperty().SetLineStippleRepeatFactor(2);a.GetProperty().SetLineStippleOn()
        except Exception: pass
    return a


def point_cloud(points, rgba=(0.8, 0.9, 1, 0.35), size=3):
    pts = np.asarray(points, float)
    vp = vtk.vtkPoints()
    for p in pts:
        vp.InsertNextPoint(*p)
    pd = vtk.vtkPolyData()
    pd.SetPoints(vp)
    glyph = vtk.vtkVertexGlyphFilter()
    glyph.SetInputData(pd)
    glyph.Update()
    mapper = vtk.vtkPolyDataMapper()
    mapper.SetInputData(glyph.GetOutput())
    a = vtk.vtkActor()
    a.SetMapper(mapper)
    a.GetProperty().SetColor(*rgba[:3])
    a.GetProperty().SetOpacity(rgba[3])
    a.GetProperty().SetPointSize(size)
    return a


def seabed(bounds, seed=7, nx=86, ny=64):
    rng = np.random.default_rng(seed)
    (xmin, xmax), (ymin, ymax), (zmin, zmax) = bounds
    xs = np.linspace(xmin, xmax, nx); ys = np.linspace(ymin, ymax, ny)
    X, Y = np.meshgrid(xs, ys, indexing="xy")
    raw = rng.normal(size=(ny, nx))
    smooth = raw.copy()
    for _ in range(7):
        smooth = (np.roll(smooth,1,0)+np.roll(smooth,-1,0)+np.roll(smooth,1,1)+np.roll(smooth,-1,1)+4*smooth)/8.0
    Z = -20.4 + 0.42*np.sin(0.11*X) * np.cos(0.15*Y) + 0.28*np.cos(0.19*Y) + 0.42*smooth/max(smooth.std(),1e-6)
    Z = np.clip(Z, zmin+0.25, zmin+4.0)
    pts = vtk.vtkPoints(); polys = vtk.vtkCellArray(); colors = vtk.vtkUnsignedCharArray(); colors.SetNumberOfComponents(3)
    colors.SetName("sediment_color")
    for j in range(ny):
        for i in range(nx):
            pts.InsertNextPoint(X[j,i],Y[j,i],Z[j,i])
            q = np.clip((Z[j,i]-(zmin+0.25))/3.8,0,1)
            n = int(6*np.sin(.25*X[j,i])+5*np.cos(.17*Y[j,i]))
            colors.InsertNextTuple3(max(30,78+n), max(24,69+n), max(18,57+n))
    for j in range(ny-1):
        for i in range(nx-1):
            a=j*nx+i; b=a+1; c=a+nx; d=c+1
            t=vtk.vtkTriangle(); t.GetPointIds().SetId(0,a); t.GetPointIds().SetId(1,b); t.GetPointIds().SetId(2,c); polys.InsertNextCell(t)
            t=vtk.vtkTriangle(); t.GetPointIds().SetId(0,b); t.GetPointIds().SetId(1,d); t.GetPointIds().SetId(2,c); polys.InsertNextCell(t)
    pd=vtk.vtkPolyData(); pd.SetPoints(pts); pd.SetPolys(polys); pd.GetPointData().SetScalars(colors)
    lut=vtk.vtkLookupTable(); lut.SetNumberOfTableValues(256); lut.SetRange(0,255)
    for i in range(256):
        q=i/255.0; lut.SetTableValue(i,.09+.12*q,.065+.09*q,.05+.07*q,1)
    m=vtk.vtkPolyDataMapper(); m.SetInputData(pd); m.SetLookupTable(lut); m.SetScalarRange(0,255)
    a=vtk.vtkActor(); a.SetMapper(m); _beautify(a,.22,.78,.06,20)
    return a


def water_surface(bounds, nx=52, ny=40):
    (xmin,xmax),(ymin,ymax),_=bounds
    xs=np.linspace(xmin,xmax,nx); ys=np.linspace(ymin,ymax,ny)
    pts=vtk.vtkPoints(); polys=vtk.vtkCellArray()
    for y in ys:
        for x in xs:
            z=.18*np.sin(.12*x)*np.cos(.11*y)+.06*np.sin(.27*y)
            pts.InsertNextPoint(x,y,z)
    for j in range(ny-1):
        for i in range(nx-1):
            a=j*nx+i;b=a+1;c=a+nx;d=c+1
            q=vtk.vtkQuad(); q.GetPointIds().SetId(0,a);q.GetPointIds().SetId(1,b);q.GetPointIds().SetId(2,d);q.GetPointIds().SetId(3,c);polys.InsertNextCell(q)
    pd=vtk.vtkPolyData();pd.SetPoints(pts);pd.SetPolys(polys)
    a=actor(pd,(.04,.34,.47,.11),.11,specular=.7,power=80)
    return a


def light_beams(bounds, count=10, seed=17):
    rng=np.random.default_rng(seed); (xmin,xmax),(ymin,ymax),_=bounds
    out=[]
    for _ in range(count):
        x=rng.uniform(xmin+2,xmax-2); y=rng.uniform(ymin+2,ymax-2)
        p1=[x,y,.0]; p2=[x+rng.uniform(-2.5,2.5), y+rng.uniform(-2.5,2.5), -17.5]
        out.append(cylinder_between(p1,p2,rng.uniform(.08,.17),(.20,.70,.90,.028),10))
    return out


def sea_grass(center, scale=1.0, rng=None):
    rng=rng or np.random.default_rng(); c=np.asarray(center,float); out=[]
    for _ in range(10):
        ang=rng.uniform(0,2*np.pi); h=rng.uniform(1.1,2.7)*scale; lean=rng.uniform(.18,.75)*scale
        tip=c+[np.cos(ang)*lean,np.sin(ang)*lean,h]
        out.append(cylinder_between(c,tip,rng.uniform(.03,.06)*scale,(.10,.30,.18,1),9))
    return out


def rock_field(center, scale=1.0, count=8, rng=None):
    rng=rng or np.random.default_rng(); c=np.asarray(center,float); out=[]
    for _ in range(count):
        p=c+np.array([rng.uniform(-2.1,2.1),rng.uniform(-1.5,1.5),rng.uniform(-.2,.35)])*scale
        out.append(sphere(p,rng.uniform(.32,1.05)*scale,(.22,.24,.23,1),18))
    return out


def coral_cluster(center, scale=1.0, rng=None):
    rng=rng or np.random.default_rng();c=np.asarray(center,float);out=[]
    cols=[(.50,.18,.42,1),(.74,.29,.52,1),(.84,.42,.32,1),(.30,.30,.56,1)]
    base=c+[0,0,-.6*scale]
    for i in range(12):
        ang=2*np.pi*i/12+rng.uniform(-.17,.17); r=rng.uniform(.2,.9)*scale
        p2=c+[r*np.cos(ang),r*np.sin(ang),rng.uniform(.7,1.8)*scale];col=cols[i%len(cols)]
        out.append(cylinder_between(base,p2,.075*scale,col,11)); tip=p2
        for _ in range(2):
            a2=ang+rng.uniform(-.75,.75); p3=tip+[.35*scale*np.cos(a2),.35*scale*np.sin(a2),.46*scale]
            out.append(cylinder_between(tip,p3,.045*scale,col,9));out.append(sphere(p3,.08*scale,col,14));tip=p3
    out.append(sphere(c,.45*scale,(.30,.11,.30,1),18)); return out


def wreck_ship(center, scale=1.0):
    c=np.asarray(center,float);out=[];rust=(.18,.14,.10,1);dark=(.07,.075,.07,1);metal=(.26,.21,.16,1)
    out += [cube(c+[-.6,0,1.0],[13*scale,3.6*scale,1.8*scale],rust,(0,0,10)), cube(c+[2.7,0,2.5],[4.4*scale,2.8*scale,2.6*scale],dark,(0,0,14)), cube(c+[.7,0,1.8],[2.4*scale,2.1*scale,1.3*scale],metal,(0,0,12))]
    for yy in (-1.45,1.45):
        for xx in (-4.5,-2.7,-.9,.9,2.7,4.5): out.append(cylinder_between(c+[xx,yy,-.15],c+[xx,yy,1.45],.075*scale,rust,9))
    out += [cylinder_between(c+[-4.7,0,2.0],c+[-6.4,0,5.6],.22*scale,dark,12), cylinder_between(c+[1.8,0,2.6],c+[1.8,0,6.0],.12*scale,dark,10)]
    for xx in (-.2,.8,1.8,2.8): out.append(sphere(c+[xx,-1.46,2.55],.20*scale,(.06,.18,.22,1),16))
    for i in range(7): out.append(cylinder_between(c+[-5+i*1.4,-1.1,1.65],c+[-4.8+i*1.4,-1.1,2.55],.045*scale,metal,8))
    out.append(cylinder_between(c+[-5,-1.1,2.55],c+[4,-1.1,2.55],.03*scale,metal,8))
    out.append(cylinder_between(c+[-5.4,2.7,-.8],c+[-1.1,4.4,-.1],.16*scale,rust,10))
    return out


def container(center, scale=1.0, rotation=0):
    c=np.asarray(center,float);out=[cube(c,[6.2*scale,2.55*scale,2.45*scale],(.22,.20,.16,1),(0,0,rotation))]
    for dx in (-2.75,-1.55,-.35,.85,2.05,2.75):
        for dy in (-1.1,1.1): out.append(cylinder_between(c+[dx,dy,-1.15],c+[dx,dy,1.15],.07*scale,(.32,.27,.21,1),9))
    for p in ([0,-1.29,.65],[2,1.31,-.6],[-1.8,-1.3,-.65]): out.append(cube(c+np.array(p)*scale,[.62*scale,.05*scale,.38*scale],(.34,.13,.07,1),(0,0,rotation)))
    return out


def dynamite_cache(center, scale=1.0):
    c=np.asarray(center,float);out=[cube(c,[3,1.9,.8],(.15,.09,.06,1))]
    for i in range(5):
        y=(i-2)*.28;out.append(cylinder_between(c+[-1.05,y,-.18],c+[1.05,y,-.18],.11*scale,(.55,.045,.035,1),14))
    out += [cylinder_between(c+[0,0,.4],c+[0,0,1.55],.045,(.24,.23,.20,1),8), sphere(c+[0,0,1.68],.15,(.90,.10,.03,1),16)]
    return out


def pipeline(center, length=18.0, angle=0.0):
    c=np.asarray(center,float); d=np.array([np.cos(angle),np.sin(angle),0.0]); p1=c-.5*length*d;p2=c+.5*length*d
    out=[cylinder_between(p1,p2,.22,(.12,.14,.14,1),18)]
    for a in np.linspace(-.44*length,.44*length,10):
        p=c+d*a; q=p+np.array([-d[1],d[0],0])*0.55; out.append(cylinder_between(p,q,.045,(.24,.23,.19,1),8))
    return out


def cable_bundle(center, length=16.0, angle=0.0):
    c=np.asarray(center,float);d=np.array([np.cos(angle),np.sin(angle),0.0]);out=[]
    for z in (-.22,0,.22):
        p1=c-.5*length*d+[0,0,z];p2=c+.5*length*d+[0,0,z+.4*np.sin(angle)]
        out.append(cylinder_between(p1,p2,.042,(.045,.045,.04,1),8))
    return out


def make_auv_actor():
    root=vtk.vtkAssembly()
    h=vtk.vtkCylinderSource();h.SetRadius(.53);h.SetHeight(5.8);h.SetResolution(44);h.Update();ha=actor(h.GetOutput(),(.74,.79,.82,1),specular=.72,power=90);ha.RotateY(90);root.AddPart(ha)
    root.AddPart(sphere([2.84,0,0],.54,(.50,.58,.63,1),28))
    tail=vtk.vtkConeSource();tail.SetRadius(.49);tail.SetHeight(1.05);tail.SetResolution(28);tail.SetDirection(-1,0,0);tail.SetCenter(-3.18,0,0);tail.Update();root.AddPart(actor(tail.GetOutput(),(.29,.35,.39,1)))
    root.AddPart(cube([-.55,0,0],[1.7,1.07,1.07],(.78,.57,.06,1)))
    root.AddPart(cube([-.90,0,0],[.18,1.09,1.09],(.12,.14,.15,1)))
    root.AddPart(cylinder_between([-.2,0,.3],[-.2,0,1.05],.105,(.08,.33,.39,1),11))
    root.AddPart(sphere([2.62,0,-.10],.18,(.08,.17,.20,1),18)); root.AddPart(sphere([2.64,0,-.09],.08,(.82,.95,.98,1),14))
    root.AddPart(cube([0,.59,-.1],[1.7,.12,.08],(.12,.20,.22,1),(0,4,8)));root.AddPart(cube([0,-.59,-.1],[1.7,.12,.08],(.12,.20,.22,1),(0,-4,-8)))
    for y in (-.68,.68):
        root.AddPart(cylinder_between([-2.7,y,0],[-3.45,y,0],.23,(.16,.19,.20,1),18));root.AddPart(sphere([-3.42,y,0],.18,(.07,.09,.10,1),16))
        for k in range(4):
            a=2*np.pi*k/4;p1=np.array([-3.44,y,0]);p2=p1+[0,.32*np.cos(a),.32*np.sin(a)];root.AddPart(cylinder_between(p1,p2,.035,(.34,.37,.38,1),8))
    root.AddPart(sphere([2.15,.34,-.26],.075,(.70,.90,1,1),14));root.AddPart(sphere([2.15,-.34,-.26],.075,(.70,.90,1,1),14))
    return root


def make_submersible_actor(scale=1.0):
    root=vtk.vtkAssembly();h=vtk.vtkCylinderSource();h.SetRadius(.31*scale);h.SetHeight(2.6*scale);h.SetResolution(30);h.Update();a=actor(h.GetOutput(),(.24,.30,.34,1),specular=.7,power=70);a.RotateY(90);root.AddPart(a)
    root.AddPart(sphere([1.27*scale,0,0],.33*scale,(.16,.22,.26,1),20));root.AddPart(cylinder_between([-.3*scale,0,0],[-.3*scale,0,.55*scale],.07*scale,(.09,.35,.43,1),9));root.AddPart(sphere([1.1*scale,0,-.08*scale],.07*scale,(.82,.95,1,1),12))
    return root


def make_debris_actor(scale=1.0):
    root=vtk.vtkAssembly();b=vtk.vtkCylinderSource();b.SetRadius(.5*scale);b.SetHeight(1.35*scale);b.SetResolution(20);b.Update();a=actor(b.GetOutput(),(.33,.25,.17,1),specular=.28,power=32);a.RotateY(62);root.AddPart(a);root.AddPart(cube([.65*scale,.08*scale,0],[.7*scale,.45*scale,.38*scale],(.42,.31,.20,1),(16,25,10)));return root


def fish_actor(center, scale=1.0, heading=0.0):
    c=np.asarray(center,float);root=vtk.vtkAssembly();root.AddPart(sphere(c,.18*scale,(.30,.44,.51,.72),16));root.AddPart(cube(c+[-.25*scale,0,0],[.28*scale,.05*scale,.20*scale],(.22,.32,.37,.65),(0,0,math.degrees(heading))));return root


def text_actor(text, position, font_size=16, color=(.92,.97,1), bg=(.02,.05,.08), bg_alpha=.74, frame=True, bold=False):
    ta=vtk.vtkTextActor();ta.SetInput(text);ta.SetPosition(int(position[0]),int(position[1]));p=ta.GetTextProperty();p.SetFontFamilyToArial();p.SetFontSize(int(font_size));p.SetColor(*color);p.SetBackgroundColor(*bg);p.SetBackgroundOpacity(float(bg_alpha));
    if frame: p.SetFrame(1);p.SetFrameColor(.18,.52,.68);p.SetFrameWidth(2)
    if bold:p.BoldOn()
    return ta


